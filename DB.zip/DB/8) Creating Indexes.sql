USE [EuroBharat]

CREATE UNIQUE NONCLUSTERED INDEX [UNC_RoleCode] ON [Ref_Roles]([Code])
CREATE UNIQUE NONCLUSTERED INDEX [UNC_CountryCode] ON [Ref_Countries]([Code])
CREATE NONCLUSTERED INDEX [NC_SCodeCID] ON [Ref_States]([Code], [CountryId])
CREATE NONCLUSTERED INDEX [NC_UsersEP] ON [tbl_Users]([EmailId],[Password])
CREATE NONCLUSTERED INDEX [NC_UsersEmail] ON [tbl_Users]([EmailId])
CREATE NONCLUSTERED INDEX [NC_UsersMobile] ON [tbl_Users]([Mobile])
CREATE NONCLUSTERED INDEX [NC_UsersRole] ON [tbl_Users]([RoleId])
CREATE NONCLUSTERED INDEX [NC_UsersSaltKey] ON [tbl_Users]([SaltKey])
CREATE NONCLUSTERED INDEX [NC_AuditsEntryForm] ON [tbl_Audits]([EntryFrom])
CREATE NONCLUSTERED INDEX [NC_AuditsIsSuccess] ON [tbl_Audits]([IsSuccess])
CREATE NONCLUSTERED INDEX [NC_UMappingPAddr] ON [tbl_UserMapping]([PermanentState],[PermanentCountry],[PermanentZipCode])
CREATE NONCLUSTERED INDEX [NC_UMappingCAddr] ON [tbl_UserMapping]([CurrentState],[CurrentCountry],[CurrentZipCode])
CREATE NONCLUSTERED INDEX [NC_MLUser] ON [tbl_MultiLogin]([UserId])
CREATE NONCLUSTERED INDEX [NC_MLSessionToken] ON [tbl_MultiLogin]([SessionToken])
CREATE NONCLUSTERED INDEX [NC_ResetPwdUser] ON [tbl_ResetPwdLog]([UserId])
CREATE NONCLUSTERED INDEX [NC_MenusOrder] ON [tbl_Menus]([Order])
CREATE NONCLUSTERED INDEX [NC_SMenusPId] ON [tbl_SubMenus]([ParentId])
CREATE NONCLUSTERED INDEX [NC_AMenusPIdRId] ON [tbl_AssignMenus]([ParentId],[RoleId])
CREATE NONCLUSTERED INDEX [NC_AccPostUser] ON [tbl_AccommodationPosts]([UserId])
CREATE NONCLUSTERED INDEX [NC_AccPostRoom] ON [tbl_AccommodationPosts]([RoomType])
CREATE NONCLUSTERED INDEX [NC_AccPostCity] ON [tbl_AccommodationPosts]([City])
CREATE NONCLUSTERED INDEX [NC_AccPostState] ON [tbl_AccommodationPosts]([StateId])
CREATE NONCLUSTERED INDEX [NC_AccPostCountry] ON [tbl_AccommodationPosts]([CountryId])
CREATE NONCLUSTERED INDEX [NC_AccPostZCode] ON [tbl_AccommodationPosts]([ZipCode])
CREATE NONCLUSTERED INDEX [NC_PageCommentsCode] ON [tbl_PagesForComments]([Code])
CREATE NONCLUSTERED INDEX [NC_CommentsUser] ON [tbl_Comments]([UserId])
CREATE NONCLUSTERED INDEX [NC_CommentsPage] ON [tbl_Comments]([PageId])
CREATE NONCLUSTERED INDEX [NC_CommentsParentC] ON [tbl_Comments]([ParentCommentId])
CREATE NONCLUSTERED INDEX [NC_BSPostsUID] ON [tbl_BuySellPosts]([UserId])
CREATE NONCLUSTERED INDEX [NC_BSPostsBSID] ON [tbl_BuySellPostImages](BuySellPostId)

-- EXECUTE SP_HELPINDEX [tbl_Users]














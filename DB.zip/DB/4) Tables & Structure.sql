USE [EuroBharat]

CREATE TABLE [tbl_Users]
(
[UserId]				INT					NOT NULL IDENTITY(1,1),
[PersonalKey]			VARCHAR(800)		NOT NULL,
[FirstName]				VARCHAR(800)		NOT NULL,
[LastName]				VARCHAR(800)		NOT NULL,
[RoleId]				INT					NOT NULL,
[Password]				VARCHAR(800)		NOT NULL,
[SaltKey]				VARCHAR(800)		NOT NULL,
[EmailId]				VARCHAR(800)		NOT NULL,
[Mobile]				VARCHAR(800)		NOT NULL,
[Photo]					VARCHAR(MAX)		NULL,
[ImgType]				VARCHAR(800)		NULL,
[Gender]				VARCHAR(300)		NULL,
[IsFirstTimeLogin]		BIT					DEFAULT 1,
[FailedLoginAttempts]	INT					DEFAULT 0,
[DisableAccountTime]	DATETIME			NULL,
[IsActive]				BIT					DEFAULT 1,
[CreatedBy]				INT					NOT NULL,
[CreatedDate]			DATETIME			DEFAULT GETDATE(),
[ModifiedBy]			INT					NULL,
[ModifiedDate]			DATETIME			NULL,
CONSTRAINT PK_tblUserId PRIMARY KEY ([UserId]),
CONSTRAINT FK_tblURole FOREIGN KEY ([CreatedBy]) REFERENCES [Ref_Roles]([RoleId]),
CONSTRAINT FK_tblUCreated FOREIGN KEY ([CreatedBy]) REFERENCES [tbl_Users]([UserId]),
CONSTRAINT FK_tblUModified FOREIGN KEY ([ModifiedBy]) REFERENCES [tbl_Users]([UserId])
)

----- END -----

CREATE TABLE [tbl_Audits]
(
[AuditId]			INT				NOT NULL IDENTITY(1,1),
[UserId]			INT				NULL,
[UserEmail]			VARCHAR(800)	NULL,
[IPAddress]			VARCHAR(100)	NOT NULL,
[EntryType]			VARCHAR(10)		NOT NULL,
[EntryFrom]			VARCHAR(10)		NOT NULL,
[Browser]			VARCHAR(600)	NOT NULL,
[Resolution]		VARCHAR(50)		NOT NULL,
[Location]			VARCHAR(500)	NOT NULL,
[Latitude]			VARCHAR(50)		NOT NULL,
[Longitude]			VARCHAR(50)		NOT NULL,
[AccessTime]		DATETIME		NOT NULL,
[IsSuccess]			BIT				NOT NULL,
CONSTRAINT PK_tblAuditId PRIMARY KEY ([AuditId])
)

----- END -----

CREATE TABLE [tbl_UserSecurityQuestions]
(
[UserId]			INT				NOT NULL,
[SecurityQue]		VARCHAR(200)	NOT NULL,
[SecurityAns]		VARCHAR(200)	NULL,
CONSTRAINT UC_USQUserSecurity UNIQUE ([UserId], [SecurityQue]),
CONSTRAINT FK_USQUser FOREIGN KEY ([UserId]) REFERENCES [tbl_Users]([UserId])
)

----- END -----

CREATE TABLE [tbl_UserMapping]
(
[UserId]					INT				NOT NULL,
[IsPermanentAddress]		BIT				NULL,
[PermanentStreetAddress]	VARCHAR(MAX)	NULL,
[PermanentCity]				VARCHAR(800)	NULL,
[PermanentState]			INT				NULL,
[PermanentCountry]			INT				NULL,
[PermanentZipCode]			BIGINT			NULL,
[CurrentStreetAddress]		VARCHAR(MAX)	NULL,
[CurrentCity]				VARCHAR(800)	NULL,
[CurrentState]				INT				NULL,
[CurrentCountry]			INT				NULL,
[CurrentZipCode]			BIGINT			NULL,
CONSTRAINT FK_UMUser FOREIGN KEY ([UserId]) REFERENCES [tbl_Users]([UserId]),
CONSTRAINT FK_UMPState FOREIGN KEY ([PermanentState]) REFERENCES [Ref_States]([StateId]),
CONSTRAINT FK_UMPCountry FOREIGN KEY ([PermanentCountry]) REFERENCES [Ref_Countries]([CountryId]),
CONSTRAINT FK_UMCState FOREIGN KEY ([CurrentState]) REFERENCES [Ref_States]([StateId]),
CONSTRAINT FK_UMCCountry FOREIGN KEY ([CurrentCountry]) REFERENCES [Ref_Countries]([CountryId])
)

----- END -----

CREATE TABLE [tbl_MultiLogin]
(
[UserId]			INT				NOT NULL,
[SessionToken]		VARCHAR(800)	NOT NULL,
[Flag]				VARCHAR(20)		NOT NULL,
[CreatedDate]		DATETIME		NOT NULL,
CONSTRAINT FK_MLUser FOREIGN KEY ([UserId]) REFERENCES [tbl_Users]([UserId])
)

----- END -----

CREATE TABLE [tbl_ResetPwdLog]
(
[ResetPwdLogId]		INT				NOT NULL IDENTITY(1,1),
[UserId]			INT				NOT NULL,
[GuidVal]			VARCHAR(800)	NOT NULL,
[IsReset]			BIT				NOT NULL,
[EntryDate]			DATETIME		NOT NULL
CONSTRAINT PK_ResetPwdLogId PRIMARY KEY ([ResetPwdLogId]),
CONSTRAINT FK_RPwdUser FOREIGN KEY ([UserId]) REFERENCES [tbl_Users]([UserId])
)

----- END -----

CREATE TABLE [tbl_Menus]
(
[ParentId]		INT				NOT NULL IDENTITY(1,1),
[Header]		VARCHAR(50)		NOT NULL,
[Controller]	VARCHAR(50)		NULL,
[Action]		VARCHAR(50)		NULL,
[HavingChild]	BIT				NOT NULL,
[Order]			INT				NOT NULL,
[Icon]			VARCHAR(50)		NOT NULL,
CONSTRAINT PK_ParentId PRIMARY KEY ([ParentId]),
CONSTRAINT UC_PHeaderControllerAction UNIQUE ([Header],[Controller],[Action])
)

----- END -----

CREATE TABLE [tbl_SubMenus]
(
[ChildId]		INT 			NOT NULL IDENTITY(1,1),
[ParentId]		INT				NOT NULL,
[Header]		VARCHAR(50)		NOT NULL,
[Controller]	VARCHAR(50)		NOT NULL,
[Action]		VARCHAR(50)		NOT NULL,
[Order]			INT				NOT NULL,
CONSTRAINT PK_ChildId PRIMARY KEY ([ChildId]),
CONSTRAINT FK_SMenusParentId FOREIGN KEY ([ParentId]) REFERENCES [tbl_Menus]([ParentId]),
CONSTRAINT UC_CHeaderControllerAction UNIQUE ([Header],[Controller],[Action])
)

----- END -----

CREATE TABLE [tbl_AssignMenus]
(
[AssignMenuId]	INT 	NOT NULL IDENTITY(1,1),
[ParentId]		INT		NOT NULL,
[RoleId]		INT		NOT NULL,
CONSTRAINT PK_AssignMenuId PRIMARY KEY ([AssignMenuId]),
CONSTRAINT FK_AMenusParentId FOREIGN KEY ([ParentId]) REFERENCES [tbl_Menus]([ParentId]),
CONSTRAINT FK_AMenusRoleId FOREIGN KEY ([RoleId]) REFERENCES [Ref_Roles]([RoleId]),
CONSTRAINT UC_AMenusParentRole UNIQUE ([ParentId],[RoleId])
)

----- END -----

CREATE TABLE [tbl_AccommodationPosts]
(
[AccommodationPostId]		INT 			NOT NULL IDENTITY(1,1),
[UserId]					INT				NOT NULL,
[Title]						VARCHAR(50)		NOT NULL,
[RoomType]					VARCHAR(50)		NOT NULL,
[Address]					VARCHAR(50)		NOT NULL,
[City]						VARCHAR(30)		NOT NULL,
[StateId]					INT				NOT NULL,
[CountryId]					INT				NOT NULL,
[ZipCode]					BIGINT			NOT NULL,
[ImagePath]					VARCHAR(MAX)	NULL,
[ImgType]					VARCHAR(100)	NULL,
[Description]				VARCHAR(300)	NOT NULL,
[CreatedDate]				DATETIME		NOT NULL
CONSTRAINT PK_AccommodationPostId PRIMARY KEY ([AccommodationPostId]),
CONSTRAINT FK_AccPUserId FOREIGN KEY ([UserId]) REFERENCES [tbl_Users]([UserId]),
CONSTRAINT FK_AccPStateId FOREIGN KEY ([StateId]) REFERENCES [Ref_States]([StateId]),
CONSTRAINT FK_AccPCountryId FOREIGN KEY ([CountryId]) REFERENCES [Ref_Countries]([CountryId]),
CONSTRAINT UC_AccPTitle UNIQUE ([Title],[UserId],[Address])	
)

----- END -----

CREATE TABLE [tbl_PagesForComments]
(
[PageId]		INT 			NOT NULL IDENTITY(1,1),
[Code]			VARCHAR(5)		NOT NULL,
[Description]	VARCHAR(100)	NOT NULL,
[CreatedDate]	DATETIME		DEFAULT GETDATE(),
[ModifiedDate]	DATETIME		NULL,
CONSTRAINT PK_CPageId PRIMARY KEY ([PageId]),
CONSTRAINT UC_CPCode UNIQUE ([Code])
)

----- END -----

CREATE TABLE [tbl_Comments]
(
[CommentId]		INT				NOT NULL IDENTITY(1,1),
[UserId]		INT				NOT NULL,
[PageId]		INT				NOT NULL,
[PageColumnId]	INT				NOT NULL,
[Comments]		VARCHAR(500)	NOT NULL,
[ParentCommentId]	INT			NOT NULL,
[HavingParentCommentId]	BIT		NOT NULL DEFAULT 0,
[CommentedDate]	DATETIME		DEFAULT GETDATE(),
CONSTRAINT PK_CommentId PRIMARY KEY ([CommentId]),
CONSTRAINT FK_CommUserId FOREIGN KEY ([UserId]) REFERENCES [tbl_Users]([UserId]),
CONSTRAINT FK_CommPageId FOREIGN KEY ([PageId]) REFERENCES [tbl_PagesForComments]([PageId])
)

----- END -----

CREATE TABLE [tbl_BuySellPosts]
(
[BuySellPostId]				INT 			NOT NULL IDENTITY(1,1),
[UserId]					INT				NOT NULL,
[Title]						VARCHAR(50)		NOT NULL,
[DisplayMobile]				BIT				NOT NULL,
[City]						VARCHAR(30)		NOT NULL,
[StateId]					INT				NOT NULL,
[CountryId]					INT				NOT NULL,
[ZipCode]					BIGINT			NOT NULL,
[Description]				VARCHAR(300)	NOT NULL,
[CreatedDate]				DATETIME		NOT NULL
CONSTRAINT PK_BuySellPostId PRIMARY KEY ([BuySellPostId]),
CONSTRAINT FK_BSPUserId FOREIGN KEY ([UserId]) REFERENCES [tbl_Users]([UserId]),
CONSTRAINT FK_BSPStateId FOREIGN KEY ([StateId]) REFERENCES [Ref_States]([StateId]),
CONSTRAINT FK_BSPCountryId FOREIGN KEY ([CountryId]) REFERENCES [Ref_Countries]([CountryId]),
CONSTRAINT UC_BSPTitle UNIQUE ([Title],[UserId])	
)

----- END -----

CREATE TABLE [tbl_BuySellPostImages]
(
[BSImgId]					INT				NOT NULL IDENTITY(1,1),
[BuySellPostId]				INT 			NOT NULL,
[ImagePath]					VARCHAR(MAX)	NOT NULL,
[ImgType]					VARCHAR(100)	NOT NULL,
CONSTRAINT PK_BSImgId PRIMARY KEY ([BSImgId]),
CONSTRAINT FK_BSPPostId FOREIGN KEY ([BuySellPostId]) REFERENCES [tbl_BuySellPosts]([BuySellPostId])
)

----- END -----

USE [EuroBharat]

INSERT [tbl_Users]
([PersonalKey],[FirstName],[LastName],[RoleId],[Password],[SaltKey],[EmailId],[Mobile],[IsFirstTimeLogin],[IsActive],[CreatedBy],[CreatedDate]) 
VALUES 
('2W6ppjh+6bi2veYXNrz3LyQVLFaj+r7/9CBL2horM8MhYF/kvm5kmSZ0t//tAStkHf0IWR8cPYE8kvPO7Qmc7w==',
'AhU+KNMJioCmoJw2oT+65g2UG+mIbJUYX2v0/BCMP6c=',
'bF3touMtIMA9H+OOVGFlNctvgi6FTNaZmF6GVQU8aw8=',
1,
'c4wEQjOGk90sA2gDiQwGPGyAT0b+R376Op6ZLtyIBgs=',
'uLbP8np1Si1KVsDuTNemr4Iba9jkkFyU+ShxsBdL41Q=',
'Xk4Zw+C8PndeMJkBKVSVw5/gINK/7S+nubH4M5gQmeg=',
'wWAOX1vUTy3SOlULE+99Bw==',
1,1,1,GETDATE())
---- Actual Values : 
--FirstName - Sampath, 
--LastName - Bandari, 
--Email - sampath.bandari51@gmail.com, 
--Mobile - 8121839354, 
--Password - Euro@123

INSERT [tbl_Users]
([PersonalKey],[FirstName],[LastName],[RoleId],[Password],[SaltKey],[EmailId],[Mobile],[IsFirstTimeLogin],[IsActive],[CreatedBy],[CreatedDate]) 
VALUES 
('Pri9MRGK50pW+0mOvtWTSzQzYlxCj0555TNohrFqnALHYVlsjxjQ85s2pE0bpIqYjU9hQDZLFuueKQdCUH3PBQ==',
'IbHPz0UgTKMODYUZ7haI1yQKH4ZUxV0YOpDJKhuR7Sk=',
'Db99fbRoNzWiblYtLSgOR2ho5rcND1eUk0CSIcRiwR4=',
4,
'c4wEQjOGk90sA2gDiQwGPGyAT0b+R376Op6ZLtyIBgs=',
'uLbP8np1Si1KVsDuTNemr4Iba9jkkFyU+ShxsBdL41Q=',
'b8J+7+g2KnmRIVFWycoWxdRzG027nBsKZJVUi/B6oAQ=',
'7p9ZrVaITz3LnhTZcDi2Ag==',
1,1,1,GETDATE())
---- Actual Values : 
--FirstName - First User, 
--LastName - Account, 
--Email - eb.user00001@gmail.com, 
--Mobile - 1234567890, 
--Password - Euro@123

INSERT [tbl_Users]
([PersonalKey],[FirstName],[LastName],[RoleId],[Password],[SaltKey],[EmailId],[Mobile],[IsFirstTimeLogin],[IsActive],[CreatedBy],[CreatedDate]) 
VALUES 
('8i+miHKWXj7WC+56RawayEkoRCc5ZFdrBGxVRt8UrbWwXDqpN6sxN0PdYX/lQdCK6559jLkKLqkxax0IGVnBuA==',
'8i3YaA1wIAbnXYCAjInQcSi+j2jIQItiZlhPEiAS+nw=',
'k/eCo8pa3pl2R3kWIufmZ4SWkg4RA+QcMgA8a8bIdGk=',
4,
'c4wEQjOGk90sA2gDiQwGPGyAT0b+R376Op6ZLtyIBgs=',
'uLbP8np1Si1KVsDuTNemr4Iba9jkkFyU+ShxsBdL41Q=',
'feE7U7OGrf3TUIcD4X3gADQr483m4lY8PUsshonX7KA=',
'YWej+2hPbLmEp/pQST+ygQ==',
1,1,1,GETDATE())
---- Actual Values : 
--FirstName - Second User, 
--LastName - Account, 
--Email - eb.user00002@gmail.com, 
--Mobile - 1234567800, 
--Password - Euro@123

INSERT [tbl_Users]
([PersonalKey],[FirstName],[LastName],[RoleId],[Password],[SaltKey],[EmailId],[Mobile],[IsFirstTimeLogin],[IsActive],[CreatedBy],[CreatedDate]) 
VALUES 
('pQh8XIm7VBiV2JTV9VdHMuqd4Bqo4RRIw/Y3SsOgMEV5TT8jKIj4lheZUNq27WuqplFp2UyEHEPG9yBg6Pavpg==',
'oIHCjvIE/veAhEuTrGxNaz/ywsqODLHgwtzt899pYpU=',
'/oRM4U7tDotf4h9+MtIABEZOfOIrBEMDSi4fYCobmI0=',
4,
'c4wEQjOGk90sA2gDiQwGPGyAT0b+R376Op6ZLtyIBgs=',
'uLbP8np1Si1KVsDuTNemr4Iba9jkkFyU+ShxsBdL41Q=',
'W43nuKwxHn4xl52GQl1SVp1bJDs1eFDWVsgmsWASX1I=',
'rkbjtMYxiDTGBiaqmgTDeg==',
1,1,1,GETDATE())
---- Actual Values : 
--FirstName - Third User, 
--LastName - Account, 
--Email - eb.user00003@gmail.com, 
--Mobile - 1234567000, 
--Password - Euro@123

INSERT [tbl_Users]
([PersonalKey],[FirstName],[LastName],[RoleId],[Password],[SaltKey],[EmailId],[Mobile],[IsFirstTimeLogin],[IsActive],[CreatedBy],[CreatedDate]) 
VALUES 
('j7U9LDvLvcRLcZICb+y4jCsJeUdyhtsaVev/IwRAMwh6SWqJzGloaj3+UQd5EyGO6Xqd89PAFYKp00zBAKy+wg==',
'fA5WyFhYYPMR7zy8H+JBVx7afSnEC/SyU7ow+FqBXbA=',
'l5lzNCLNzG2YHUc2D02cxJXC9/GianpQdSWO2yRDEqQ=',
5,
'c4wEQjOGk90sA2gDiQwGPGyAT0b+R376Op6ZLtyIBgs=',
'uLbP8np1Si1KVsDuTNemr4Iba9jkkFyU+ShxsBdL41Q=',
'lbb5C7bK9AA2DvtcLtiXTpWxt8iSprofUHJfDZk0nZ8=',
'r/d1DcCX+YgTbzw7RiSseQ==',
1,1,1,GETDATE())
---- Actual Values : 
--FirstName - First Business, 
--LastName - Account, 
--Email - eb.business00001@gmail.com, 
--Mobile - 1234560000, 
--Password - Euro@123

INSERT [tbl_Users]
([PersonalKey],[FirstName],[LastName],[RoleId],[Password],[SaltKey],[EmailId],[Mobile],[IsFirstTimeLogin],[IsActive],[CreatedBy],[CreatedDate]) 
VALUES 
('j7U9LDvLvcRLcZICb+y4jCsJeUdyhtsaVev/IwRAMwh6SWqJzGloaj3+UQd5EyGO6Xqd89PAFYKp00zBAKy+wg==',
'kJU53KYFvUCUQ+eXihaxFz80gqhEqkeQhsGCQlwiyxY=',
'R4DZKmHlBM0ItyYXiMXIKl3Eoxsv9aZBPDlDY0HlRoc=',
5,
'c4wEQjOGk90sA2gDiQwGPGyAT0b+R376Op6ZLtyIBgs=',
'uLbP8np1Si1KVsDuTNemr4Iba9jkkFyU+ShxsBdL41Q=',
'e3c4ti8c0Urc/vyLcT5eJVwU40Q1dQd/Tl2TKLIw6os=',
'P50mVXiteYGqZiOsD2/1fw==',
1,1,1,GETDATE())
---- Actual Values : 
--FirstName - Second Business, 
--LastName - Account, 
--Email - eb.business00002@gmail.com, 
--Mobile - 1234500000, 
--Password - Euro@123

INSERT [tbl_Users]
([PersonalKey],[FirstName],[LastName],[RoleId],[Password],[SaltKey],[EmailId],[Mobile],[IsFirstTimeLogin],[IsActive],[CreatedBy],[CreatedDate]) 
VALUES 
('PQF01VRfW81ypuxjPcYj0h4sUcFpcPwiObTRlReY7mmoXERGyoPnpEc3jKoFmbwAQIh8tJ6MiQ5Xa9+gDBgP6w==',
'Km6aurRONbaKt++pPc+BUp8/fOcVwNZnyV11odvaEgA=',
'eVVzKsV1TwC7zgNovlYfYZl72936AJLl9RiQMy/kx58=',
6,
'c4wEQjOGk90sA2gDiQwGPGyAT0b+R376Op6ZLtyIBgs=',
'uLbP8np1Si1KVsDuTNemr4Iba9jkkFyU+ShxsBdL41Q=',
'erd3JVarXKexFknEPqLZd1bwmvECjCF4r4Is0bes8sg=',
'uIV8l9p+h0vfC6TuO1z+qg==',
1,1,1,GETDATE())
---- Actual Values : 
--FirstName - First Community, 
--LastName - Account, 
--Email - eb.community00001@gmail.com,
--Mobile - 1234000000, 
--Password - Euro@123

INSERT [tbl_Users]
([PersonalKey],[FirstName],[LastName],[RoleId],[Password],[SaltKey],[EmailId],[Mobile],[IsFirstTimeLogin],[IsActive],[CreatedBy],[CreatedDate]) 
VALUES 
('QCXEicHDtVOpYW4W0NOt03XUZjnGyYZv1UrqDnR0d9ttvA137n6f/WyR2MduqSJ6OukzEelrdXXaPTVjlr7MGA==',
'jQ99Cfw87fBEWZWvk4swuVN6ZTwvR7SGSi13EuLxVtyijxdXI6O8BCgGQVruJa3y',
'lhtneExtzAae4dn4TLODW+7MI1yz/bvrDsY1PzerExY=',
6,
'c4wEQjOGk90sA2gDiQwGPGyAT0b+R376Op6ZLtyIBgs=',
'uLbP8np1Si1KVsDuTNemr4Iba9jkkFyU+ShxsBdL41Q=',
'erd3JVarXKexFknEPqLZd7L2/TEquc1b7MUyEM2Vq2o=',
'2OgC8MI4wAxA2EcH1pX7bw==',
1,1,1,GETDATE())
---- Actual Values : 
--FirstName - Second Community, 
--LastName - Account, 
--Email - eb.community00002@gmail.com,
--Mobile - 1230000000, 
--Password - Euro@123

----- END -----

INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Dashboard', 'CPanelDev', 'Dashboard', 0, 1, 'fa fa-bookmark-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('All Users', NULL, NULL, 1, 2, 'fa fa-user-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Master Data', NULL, NULL, 1, 3, 'fa fa-star-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Error Log', 'CPanelDev', 'ViewErrorLog', 0, 4, 'fa fa-exclamation-triangle')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Coming Soon', 'CPanelDev', 'ComingSoon', 0, 5, 'fa fa-share')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Dashboard', 'CPanelUser', 'Dashboard', 0, 1, 'fa fa-bookmark-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Accommodation', NULL, NULL, 1, 2, 'fa fa-user-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Buy / Sell',  NULL, NULL, 1, 3, 'fa fa-star-o')

----- END -----

INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (2, 'Create', 'CPanelDev', 'CreateAllUsers', 1)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (2, 'Details', 'CPanelDev', 'AllUserDetails', 2)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Roles', 'CPanelDev', 'CreateRole', 1)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Menus', 'CPanelDev', 'CreateMenus', 2)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Sub Menus', 'CPanelDev', 'CreateSubMenus', 3)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Assigned Menus', 'CPanelDev', 'CreateAssignedMenus', 4)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Countries', 'CPanelDev', 'CreateCountries', 5)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'States', 'CPanelDev', 'CreateStates', 6)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (7, 'Posts', 'CPanelUser', 'AccommodationPosts', 1)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (7, 'Requests', 'CPanelUser', 'AccommodationRequests', 2)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (8, 'Posts', 'CPanelUser', 'BuySellPosts', 1)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (8, 'Requests', 'CPanelUser', 'BuySellRequests', 2)

----- END -----

INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (1, 1)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (2, 1)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (3, 1)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (4, 1)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (5, 1)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (6, 4)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (7, 4)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (8, 4)

----- END -----

INSERT INTO [tbl_PagesForComments] ([Code], [Description]) VALUES ('ACPOS', 'AccPosts')
INSERT INTO [tbl_PagesForComments] ([Code], [Description]) VALUES ('BSPOS', 'BuySellPosts')
INSERT INTO [tbl_PagesForComments] ([Code], [Description]) VALUES ('ACREQ', 'AccRequests')
INSERT INTO [tbl_PagesForComments] ([Code], [Description]) VALUES ('BSREQ', 'BuySellRequests')


----- END -----

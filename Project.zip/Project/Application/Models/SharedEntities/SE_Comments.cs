﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Application.Models.SharedEntities
{
    public class SE_Comments
    {
        public int CommentId { get; set; }
        public int ReplyUserId { get; set; }
        public string ReplyFirstName { get; set; }
        public string ReplyLastName { get; set; }
        public string ReplyPhoto { get; set; }
        public int PageId { get; set; }
        public int PageColumnId { get; set; }
        public int ParentCommentId { get; set; }
        public bool HavingParentCommentId { get; set; }
        public string Comments { get; set; }
        public DateTime CommentedDate { get; set; }
        public string FullStringDate { get; set; }
        public List<SE_Comments> InnerComments { get; set; }
    }

    public class ViewPost_Comments
    {
        public SE_Accommodation ViewPost { get; set; }
        public IEnumerable<SE_Comments> CommentsList { get; set; }
        public int TotalComments { get; set; }
        public string RawHTML { get; set; }
    }

    public class ViewBSPost_Comments
    {
        public SE_BuySell ViewBSPost { get; set; }
        public IEnumerable<SE_Comments> CommentsList { get; set; }
        public int TotalComments { get; set; }
        public string RawHTML { get; set; }
    }
}
﻿using Application.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Application.Models.SharedEntities
{
    public class SE_OAuth
    {
        public string OAuthClient = GlobalVariables.Shared.OAuthClientId;
        public string OAuthClientSecret = GlobalVariables.Shared.OAuthClientSecret;
        public double OAuthTokenExpireSeconds = Convert.ToDouble(GlobalVariables.Shared.OAuthTokenExpireSeconds);
    }
}
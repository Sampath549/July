﻿using Application.Helper;
using Application.Models.SharedEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Application.Models.DataObjects
{
    public partial class TokenDAL : DataAccessComponent
    {
        SharedDAL _ObjShared = new SharedDAL();
        public SE_Users TokenAuthentication(string Email, string Password)
        {
            SE_Users _Result = new SE_Users();
            DataSet ds = new DataSet();
            string _Check = _ObjShared.GetSaltKeyByEmail(SymmetricAlgorithm.Encrypt(Email));
            if (_Check != null)
            {
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT R.Code AS RoleCode FROM [EuroDB].[tbl_Users] U INNER JOIN [EuroDB].[Ref_Roles] R ON U.RoleId = R.RoleId WHERE EmailId= @Email AND Password = @Password", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@Email", SymmetricAlgorithm.Encrypt(Email));
                        da.SelectCommand.Parameters.AddWithValue("@Password", PasswordEncryption.EncodePassword(Password, AES_Algorithm.DecryptString(_Check)));

                        da.Fill(ds);
                    }
                }

                if (ds.Tables[0].Rows.Count > 0)
                {
                    _Result.Status = 1;
                    _Result.RoleCode = ds.Tables[0].Rows[0]["RoleCode"].ToString();
                }
                else
                    _Result.Status = 0;
            }
            else
                _Result.Status = 0;

            return _Result;
        }
    }
}
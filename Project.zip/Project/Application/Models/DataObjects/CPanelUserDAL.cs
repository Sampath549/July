﻿using Application.Helper;
using Application.Models.SharedEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Application.Models.DataObjects
{
    public partial class CPanelUserDAL : DataAccessComponent
    {
        public List<SE_Accommodation> GridAccPosts(int _PNum, int _PSize, int? UID)
        {
            try
            {
                List<SE_Accommodation> _Rec = new List<SE_Accommodation>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_GridAccPosts", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@PNum", _PNum);
                        da.SelectCommand.Parameters.AddWithValue("@PSize", _PSize);
                        da.SelectCommand.Parameters.AddWithValue("@UID", UID);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_Accommodation { AccommodationId = Convert.ToInt32(dr["AccommodationPostId"]), UserId = Convert.ToInt32(dr["UserId"]), Title = dr["Title"].ToString(), RoomType = dr["RoomType"].ToString(), Address = dr["Address"].ToString(), City = dr["City"].ToString(), StateId = dr["StateId"].ToString(), StateDesc = dr["StateDesc"].ToString(), CountryId = dr["CountryId"].ToString(), CountryDesc = dr["CountryDesc"].ToString(), ZipCode = dr["ZipCode"].ToString(), Description = dr["Description"].ToString(), CreatedDate = Convert.ToDateTime(dr["CreatedDate"]), DateLongString = dr["DateLongString"].ToString(), TotalComments = Convert.ToInt32(dr["TotalComments"]), TotalRecords = Convert.ToInt32(dr["TotalRecords"]), ImagePath = Convert.ToString(dr["ImagePath"]), ImgType = Convert.ToString(dr["ImgType"]) });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public ViewPost_Comments SinglePosts(int UID, int PageColumnId)
        {
            try
            {
                ViewPost_Comments _Rec = new ViewPost_Comments();
                List<SE_Accommodation> _Rec1 = new List<SE_Accommodation>();
                List<SE_Comments> _Rec2 = new List<SE_Comments>();
                DataSet _Result1 = new DataSet();
                DataSet _Result2 = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_AccPostById", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@PageColumnId", PageColumnId);
                        da.Fill(_Result1);
                    }

                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_Comments", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@UID", UID);
                        da.SelectCommand.Parameters.AddWithValue("@PageId", 1);
                        da.SelectCommand.Parameters.AddWithValue("@PageColumnId", _Result1.Tables[0].Rows[0]["AccommodationPostId"]);
                        da.Fill(_Result2);
                    }
                    con.Close();
                }

                if (_Result1.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result1.Tables[0].Rows)
                    {
                        _Rec1.Add(new SE_Accommodation
                        {
                            AccommodationId = Convert.ToInt32(dr["AccommodationPostId"]),
                            UserId = Convert.ToInt32(dr["UserId"]),
                            FirstName = RSAPattern.Encrypt(AES_Algorithm.DecryptString(dr["FirstName"].ToString())),
                            LastName = RSAPattern.Encrypt(AES_Algorithm.DecryptString(dr["LastName"].ToString())),
                            Title = dr["Title"].ToString(),
                            RoomType = dr["RoomType"].ToString(),
                            Address = dr["Address"].ToString(),
                            City = dr["City"].ToString(),
                            StateId = dr["StateId"].ToString(),
                            StateDesc = dr["StateDesc"].ToString(),
                            CountryId = dr["CountryId"].ToString(),
                            CountryDesc = dr["CountryDesc"].ToString(),
                            ZipCode = dr["ZipCode"].ToString(),
                            Description = dr["Description"].ToString(),
                            CreatedDate = Convert.ToDateTime(dr["CreatedDate"]),
                            DateLongString = dr["DateLongString"].ToString(),
                            ImagePath = Convert.ToString(dr["ImagePath"]),
                            ImgType = dr["ImgType"].ToString()
                        });
                    }

                _Rec.ViewPost = _Rec1[0];
                _Rec.CommentsList = ResultSetData(_Result2);
                int _CommentsCount = 0;

                foreach (var C in _Rec.CommentsList)
                {
                    _CommentsCount += 1;
                    if (C.InnerComments.Count > 0)
                        _CommentsCount = _InnerComments(C.InnerComments, _CommentsCount);
                }

                _Rec.TotalComments = _CommentsCount;

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private List<SE_Comments> ResultSetData(DataSet _Result)
        {
            List<SE_Comments> _List = new List<SE_Comments>();
            if (_Result.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr1 in _Result.Tables[0].Rows)
                {
                    SE_Comments _Rec1 = new SE_Comments();
                    _Rec1.CommentId = Convert.ToInt32(dr1["CommentId"]);
                    _Rec1.ParentCommentId = Convert.ToInt32(dr1["ParentCommentId"]);
                    _Rec1.Comments = dr1["Comments"].ToString();
                    _Rec1.ReplyUserId = Convert.ToInt32(dr1["UserId"]);
                    _Rec1.PageId = Convert.ToInt32(dr1["PageId"]);
                    _Rec1.PageColumnId = Convert.ToInt32(dr1["PageColumnId"]);
                    _Rec1.ReplyFirstName = RSAPattern.Encrypt(AES_Algorithm.DecryptString(dr1["FirstName"].ToString()));
                    _Rec1.ReplyLastName = RSAPattern.Encrypt(AES_Algorithm.DecryptString(dr1["LastName"].ToString()));
                    _Rec1.ReplyPhoto = dr1["Photo"].ToString();
                    if (_Rec1.ReplyPhoto != null || _Rec1.ReplyPhoto != "")
                        _Rec1.ReplyPhoto = dr1["Photo"].ToString();
                    else
                        _Rec1.ReplyPhoto = "";
                    _Rec1.CommentedDate = Convert.ToDateTime(dr1["CommentedDate"]);
                    _Rec1.HavingParentCommentId = Convert.ToBoolean(dr1["HavingParentCommentId"]);
                    if (_Rec1.HavingParentCommentId)
                    {
                        _Rec1.InnerComments = InnerResultSetData(_Result, _Rec1.CommentId);
                    }
                    else
                        _Rec1.InnerComments = new List<SE_Comments>();
                    _List.Add(_Rec1);
                }
            }
            return _List;
        }
        private List<SE_Comments> InnerResultSetData(DataSet _Result, int CommentId)
        {
            List<SE_Comments> _InnerList = new List<SE_Comments>();
            foreach (DataRow dr in _Result.Tables[1].Rows)
            {
                SE_Comments _Rec = new SE_Comments();
                if (CommentId == Convert.ToInt32(dr["ParentCommentId"]))
                {
                    _Rec.CommentId = Convert.ToInt32(dr["CommentId"]);
                    _Rec.ParentCommentId = Convert.ToInt32(dr["ParentCommentId"]);
                    _Rec.Comments = dr["Comments"].ToString();
                    _Rec.ReplyUserId = Convert.ToInt32(dr["UserId"]);
                    _Rec.PageId = Convert.ToInt32(dr["PageId"]);
                    _Rec.PageColumnId = Convert.ToInt32(dr["PageColumnId"]);
                    _Rec.ReplyFirstName = RSAPattern.Encrypt(AES_Algorithm.DecryptString(dr["FirstName"].ToString()));
                    _Rec.ReplyLastName = RSAPattern.Encrypt(AES_Algorithm.DecryptString(dr["LastName"].ToString()));
                    _Rec.ReplyPhoto = dr["Photo"].ToString() != "" ? RSAPattern.Encrypt(dr["Photo"].ToString()) : "";
                    _Rec.CommentedDate = Convert.ToDateTime(dr["CommentedDate"]);
                    _Rec.HavingParentCommentId = Convert.ToBoolean(dr["HavingParentCommentId"]);
                    if (_Rec.HavingParentCommentId)
                        _Rec.InnerComments = InnerResultSetData(_Result, _Rec.CommentId);
                    else
                        _Rec.InnerComments = new List<SE_Comments>();
                    _InnerList.Add(_Rec);
                }
            }
            return _InnerList;
        }
        public int InsertAccPosts(SE_Accommodation _AccPosts)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Insert_AccPosts";
                cmd.Parameters.Add("@UserId", SqlDbType.VarChar).Value = _AccPosts.UserId;
                cmd.Parameters.Add("@Title", SqlDbType.VarChar).Value = _AccPosts.Title;
                cmd.Parameters.Add("@RoomType", SqlDbType.VarChar).Value = _AccPosts.RoomType;
                cmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = _AccPosts.Address;
                cmd.Parameters.Add("@City", SqlDbType.VarChar).Value = _AccPosts.City;
                cmd.Parameters.Add("@StateId", SqlDbType.Int).Value = _AccPosts.StateId;
                cmd.Parameters.Add("@CountryId", SqlDbType.Int).Value = _AccPosts.CountryId;
                cmd.Parameters.Add("@ZipCode", SqlDbType.Int).Value = _AccPosts.ZipCode;
                cmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = _AccPosts.Description;
                cmd.Parameters.Add("@ImagePath", SqlDbType.VarChar).Value = _AccPosts.ImagePath;
                cmd.Parameters.Add("@ImgType", SqlDbType.VarChar).Value = _AccPosts.ImgType;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public int DeleteAccPosts(int UID, int AID)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Delete_AccPosts";
                cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = UID;
                cmd.Parameters.Add("@AccPostId", SqlDbType.Int).Value = AID;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public int InsertComments(string Comments, int PageColumnId, string PageIdVal, int UserId)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Insert_Comments";
                cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = UserId;
                cmd.Parameters.Add("@PageIdVal", SqlDbType.VarChar).Value = PageIdVal;
                cmd.Parameters.Add("@PageColumnId", SqlDbType.Int).Value = PageColumnId;
                cmd.Parameters.Add("@Comments", SqlDbType.VarChar).Value = Comments;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public int InsertReplyComments(string Comments, int PageColumnId, string PageIdVal, int UserId, int ParentCommentId)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Insert_ReplyComments";
                cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = UserId;
                cmd.Parameters.Add("@PageIdVal", SqlDbType.VarChar).Value = PageIdVal;
                cmd.Parameters.Add("@PageColumnId", SqlDbType.Int).Value = PageColumnId;
                cmd.Parameters.Add("@Comments", SqlDbType.VarChar).Value = Comments;
                cmd.Parameters.Add("@ParentCommentId", SqlDbType.Int).Value = ParentCommentId;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public List<SE_Accommodation> GridAccRequests(int _PNum, int _PSize, int UID)
        {
            try
            {
                List<SE_Accommodation> _Rec = new List<SE_Accommodation>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_GridAccPosts", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@PNum", _PNum);
                        da.SelectCommand.Parameters.AddWithValue("@PSize", _PSize);
                        da.SelectCommand.Parameters.AddWithValue("@UID", UID);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_Accommodation { AccommodationId = Convert.ToInt32(dr["AccommodationPostId"]), UserId = Convert.ToInt32(dr["UserId"]), Title = dr["Title"].ToString(), RoomType = dr["RoomType"].ToString(), Address = dr["Address"].ToString(), City = dr["City"].ToString(), StateId = dr["StateId"].ToString(), StateDesc = dr["StateDesc"].ToString(), CountryId = dr["CountryId"].ToString(), CountryDesc = dr["CountryDesc"].ToString(), ZipCode = dr["ZipCode"].ToString(), Description = dr["Description"].ToString(), CreatedDate = Convert.ToDateTime(dr["CreatedDate"]), DateLongString = dr["DateLongString"].ToString(), TotalComments = Convert.ToInt32(dr["TotalComments"]), TotalRecords = Convert.ToInt32(dr["TotalRecords"]), ImagePath = Convert.ToString(dr["ImagePath"]), ImgType = Convert.ToString(dr["ImgType"]) });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public ViewPost_Comments SingleRequests(int UID, int PageColumnId)
        {
            try
            {
                ViewPost_Comments _Rec = new ViewPost_Comments();
                List<SE_Accommodation> _Rec1 = new List<SE_Accommodation>();
                List<SE_Comments> _Rec2 = new List<SE_Comments>();
                DataSet _Result1 = new DataSet();
                DataSet _Result2 = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_AccRequestById", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@UID", UID);
                        da.SelectCommand.Parameters.AddWithValue("@PageColumnId", PageColumnId);
                        da.Fill(_Result1);
                    }

                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_CommentsReq", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@UID", UID);
                        da.SelectCommand.Parameters.AddWithValue("@PageId", 1);
                        da.SelectCommand.Parameters.AddWithValue("@PageColumnId", _Result1.Tables[0].Rows[0]["AccommodationPostId"]);
                        da.Fill(_Result2);
                    }
                    con.Close();
                }

                if (_Result1.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result1.Tables[0].Rows)
                    {
                        _Rec1.Add(new SE_Accommodation
                        {
                            AccommodationId = Convert.ToInt32(dr["AccommodationPostId"]),
                            UserId = Convert.ToInt32(dr["UserId"]),
                            FirstName = RSAPattern.Encrypt(AES_Algorithm.DecryptString(dr["FirstName"].ToString())),
                            LastName = RSAPattern.Encrypt(AES_Algorithm.DecryptString(dr["LastName"].ToString())),
                            Title = dr["Title"].ToString(),
                            RoomType = dr["RoomType"].ToString(),
                            Address = dr["Address"].ToString(),
                            City = dr["City"].ToString(),
                            StateId = dr["StateId"].ToString(),
                            StateDesc = dr["StateDesc"].ToString(),
                            CountryId = dr["CountryId"].ToString(),
                            CountryDesc = dr["CountryDesc"].ToString(),
                            ZipCode = dr["ZipCode"].ToString(),
                            Description = dr["Description"].ToString(),
                            CreatedDate = Convert.ToDateTime(dr["CreatedDate"]),
                            DateLongString = dr["DateLongString"].ToString(),
                            ImagePath = Convert.ToString(dr["ImagePath"]),
                            ImgType = dr["ImgType"].ToString()
                        });
                    }

                _Rec.ViewPost = _Rec1[0];
                _Rec.CommentsList = ResultSetData(_Result2);
                int _CommentsCount = 0;

                foreach (var C in _Rec.CommentsList)
                {
                    _CommentsCount += 1;
                    if (C.InnerComments.Count > 0)
                        _CommentsCount = _InnerComments(C.InnerComments, _CommentsCount);
                }

                _Rec.TotalComments = _CommentsCount;

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private int _InnerComments(List<SE_Comments> Rec, int _CommentsCount)
        {
            foreach (var C in Rec)
            {
                _CommentsCount += 1;
                if (C.InnerComments.Count > 0)
                    _CommentsCount = _InnerComments(C.InnerComments, _CommentsCount);
            }
            return _CommentsCount;
        }
        public List<SE_BuySell> GridBuySellPosts(int _PNum, int _PSize, int UID)
        {
            try
            {
                List<SE_BuySell> _Rec = new List<SE_BuySell>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_GridBuySellPosts", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@PNum", _PNum);
                        da.SelectCommand.Parameters.AddWithValue("@PSize", _PSize);
                        da.SelectCommand.Parameters.AddWithValue("@UID", UID);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_BuySell { BuySellId = Convert.ToInt32(dr["BuySellPostId"]), UserId = Convert.ToInt32(dr["UserId"]), Title = dr["Title"].ToString(), DisplayMobile = Convert.ToBoolean(dr["DisplayMobile"]), City = dr["City"].ToString(), StateId = dr["StateId"].ToString(), StateDesc = dr["StateDesc"].ToString(), CountryId = dr["CountryId"].ToString(), CountryDesc = dr["CountryDesc"].ToString(), ZipCode = dr["ZipCode"].ToString(), Description = dr["Description"].ToString(), CreatedDate = Convert.ToDateTime(dr["CreatedDate"]), DateLongString = dr["DateLongString"].ToString(), TotalComments = Convert.ToInt32(dr["TotalComments"]), TotalRecords = Convert.ToInt32(dr["TotalRecords"]), ImagePath = dr["ImagePath"].ToString(), ImgType = dr["ImgType"].ToString() });

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int InsertBuySellPosts(SE_BuySell _BSPosts)
        {
            SqlConnection con = new SqlConnection(DBConnect);
            con.Open();
            int Status = 0;
            try
            {
                DataTable _Images = new DataTable();
                _Images.Columns.Add("ImgId");
                _Images.Columns.Add("ImagePath");
                _Images.Columns.Add("ImgType");
                int i = 1;

                if (_BSPosts.Images != null)
                {
                    foreach (var Rec in _BSPosts.Images)
                    {
                        DataRow _dr = _Images.NewRow();
                        _dr["ImgId"] = i;
                        _dr["ImagePath"] = Rec.ImagePath;
                        _dr["ImgType"] = Rec.ImgType;
                        _Images.Rows.Add(_dr);
                        i++;
                    }
                }

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Insert_BuySellPosts";
                cmd.Parameters.Add("@UserId", SqlDbType.VarChar).Value = _BSPosts.UserId;
                cmd.Parameters.Add("@Title", SqlDbType.VarChar).Value = _BSPosts.Title;
                cmd.Parameters.Add("@DisplayMobile", SqlDbType.Bit).Value = _BSPosts.DisplayMobile;
                cmd.Parameters.Add("@City", SqlDbType.VarChar).Value = _BSPosts.City;
                cmd.Parameters.Add("@StateId", SqlDbType.Int).Value = _BSPosts.StateId;
                cmd.Parameters.Add("@CountryId", SqlDbType.Int).Value = _BSPosts.CountryId;
                cmd.Parameters.Add("@ZipCode", SqlDbType.Int).Value = _BSPosts.ZipCode;
                cmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = _BSPosts.Description;
                cmd.Parameters.Add("@tbl_Images", SqlDbType.Structured).Value = _Images;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public ViewBSPost_Comments SingleBSPosts(int UID, int PageColumnId)
        {
            try
            {
                ViewBSPost_Comments _Rec = new ViewBSPost_Comments();
                List<SE_BuySell> _Rec1 = new List<SE_BuySell>();
                List<SE_Comments> _Rec2 = new List<SE_Comments>();
                DataSet _Result1 = new DataSet();
                DataSet _Result2 = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_BuySellPostById", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@PageColumnId", PageColumnId);
                        da.Fill(_Result1);
                    }

                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_Comments", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@UID", UID);
                        da.SelectCommand.Parameters.AddWithValue("@PageId", 2);
                        da.SelectCommand.Parameters.AddWithValue("@PageColumnId", _Result1.Tables[0].Rows[0]["BuySellPostId"]);
                        da.Fill(_Result2);
                    }
                    con.Close();
                }

                if (_Result1.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result1.Tables[0].Rows)
                    {
                        _Rec1.Add(new SE_BuySell
                        {
                            BuySellId = Convert.ToInt32(dr["BuySellPostId"]),
                            UserId = Convert.ToInt32(dr["UserId"]),
                            FirstName = RSAPattern.Encrypt(AES_Algorithm.DecryptString(dr["FirstName"].ToString())),
                            LastName = RSAPattern.Encrypt(AES_Algorithm.DecryptString(dr["LastName"].ToString())),
                            Title = dr["Title"].ToString(),
                            DisplayMobile = Convert.ToBoolean(dr["DisplayMobile"]),
                            City = dr["City"].ToString(),
                            StateId = dr["StateId"].ToString(),
                            StateDesc = dr["StateDesc"].ToString(),
                            CountryId = dr["CountryId"].ToString(),
                            CountryDesc = dr["CountryDesc"].ToString(),
                            ZipCode = dr["ZipCode"].ToString(),
                            Description = dr["Description"].ToString(),
                            CreatedDate = Convert.ToDateTime(dr["CreatedDate"]),
                            DateLongString = dr["DateLongString"].ToString(),
                            ImagePath = Convert.ToString(dr["ImagePath"]),
                            ImgType = dr["ImgType"].ToString()
                        });
                    }

                _Rec.ViewBSPost = _Rec1[0];
                _Rec.CommentsList = ResultSetData(_Result2);
                int _CommentsCount = 0;

                foreach (var C in _Rec.CommentsList)
                {
                    _CommentsCount += 1;
                    if (C.InnerComments.Count > 0)
                        _CommentsCount = _InnerComments(C.InnerComments, _CommentsCount);
                }

                _Rec.TotalComments = _CommentsCount;

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<SE_Accommodation> GetAccRequests(int Id)
        {
            try
            {
                List<SE_Accommodation> _Rec = new List<SE_Accommodation>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("USP_Get_AccRequests", con);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@UID", Id);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                    {
                        if (Convert.ToInt32(dr["TotalComments"]) != 0)
                            _Rec.Add(new SE_Accommodation { AccommodationId = Convert.ToInt32(dr["AccommodationPostId"]), Title = dr["Title"].ToString(), TotalComments = Convert.ToInt32(dr["TotalComments"]) });
                    }

                return _Rec;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Application.Models.DataObjects
{
    public partial class SharedDAL : DataAccessComponent
    {
        public string GetSaltKeyByEmail(string _Email)
        {
            try
            {
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT SaltKey FROM [EuroDB].[tbl_Users] WHERE EmailId = @Email", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@Email", _Email);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    return Convert.ToString(_Result.Tables[0].Rows[0]["SaltKey"]);
                else
                    return "";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string GetSaltKeyById(string _Id)
        {
            try
            {
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT SaltKey FROM [EuroDB].[tbl_Users] WHERE UserId = @ID", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@ID", _Id);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    return Convert.ToString(_Result.Tables[0].Rows[0]["SaltKey"]);
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int GetUserIdByEmail(string _Email)
        {
            try
            {
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT UserId FROM [EuroDB].[tbl_Users] WHERE EmailId = @Email", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@Email", _Email);
                        da.Fill(_Result);
                    }
                }
                if (_Result.Tables[0].Rows.Count > 0)
                    return Convert.ToInt32(_Result.Tables[0].Rows[0]["UserId"]);
                else
                    return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string GetFullNameByEmail(string _Email)
        {
            try
            {
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DBConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT FirstName, LastName FROM [EuroDB].[tbl_Users] WHERE EmailId = @Email", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@Email", _Email);
                        da.Fill(_Result);
                    }
                }
                if (_Result.Tables[0].Rows.Count > 0)
                    return Convert.ToString(_Result.Tables[0].Rows[0]["FirstName"]) + "^" + Convert.ToString(_Result.Tables[0].Rows[0]["LastName"]);
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
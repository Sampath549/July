﻿using Application.Models.DataObjects;
using Application.Models.SharedEntities;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.OAuth;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;

namespace Application.Filters
{
    public class AuthorizationServerProvider : OAuthAuthorizationServerProvider
    {
        private TokenDAL objToken;
        public AuthorizationServerProvider()
        {
            objToken = new TokenDAL();
        }
        public override Task ValidateClientAuthentication(OAuthValidateClientAuthenticationContext context)
        {
            var objOAuthValues = new SE_OAuth();
            context.Validated();

            string _ClientId;
            string _ClientSecret;
            context.TryGetFormCredentials(out _ClientId, out _ClientSecret);

            if (_ClientId == objOAuthValues.OAuthClient && _ClientSecret == objOAuthValues.OAuthClientSecret)
            {
                context.Validated(_ClientId);
            }
            else
            {
                context.SetError("invalid_client", "Client credentials could not be retrieved from the Authorization header");
                context.Rejected();
            }
            return base.ValidateClientAuthentication(context);
        }
        public override Task GrantResourceOwnerCredentials(OAuthGrantResourceOwnerCredentialsContext context)
        {
            var allowedOrigin = "*";
            context.OwinContext.Response.Headers.Add("Access-Control-Allow-Origin", new[] { allowedOrigin });

            SE_Users _User = objToken.TokenAuthentication(context.UserName, context.Password);
            if (_User.Status == 0)
            {
                context.SetError("invalid_grant", "The User Name OR Password is Incorrect.");
                context.Rejected();
            }
            else
            {
                var oAuthIdentity = new ClaimsIdentity(context.Options.AuthenticationType);
                oAuthIdentity.AddClaim(new Claim(ClaimTypes.Role, _User.RoleCode));
                var ticket = new AuthenticationTicket(oAuthIdentity, new AuthenticationProperties());
                context.Validated(ticket);
            }
            return base.GrantResourceOwnerCredentials(context);
        }
    }
}
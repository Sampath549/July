﻿jQuery.validator.addMethod("lettersonly", function (value, element) {
    return this.optional(element) || /^[a-z\s]+$/i.test(value);
}, "Enter Only Alphabets");

$(document).ready(function () {
    GetTable();

    $('#btnSave').val("Save");

    $("#btnCancel").click(function () {
        ClearFields();
    });

    $("#RoleDetails").validate({
        rules: {
            txtCode: {
                required: true,
                minlength: 2,
                lettersonly: true
            },
            txtDesc: {
                required: true,
                minlength: 2,
                lettersonly: true
            }
        },
        messages: {
            txtCode: {
                required: 'Enter Code.',
                minlength: 'Must enter Minimum of 2 characters'
            },
            txtDesc: {
                required: 'Enter Description.',
                minlength: 'Must enter Minimum of 2 characters'
            }
        },
        submitHandler: function () {
            SaveUpdate();
        }
    });
});


function SaveUpdate() {
    $(".loadingImg").show();
    $.ajax({
        url: '/CPanelDev/SaveUpdateRole',
        type: 'POST',
        data: JSON.stringify({ "Code": $("#txtCode").val(), "Description": $("#txtDesc").val(), "ButtonType": $('#btnSave').val() }),
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
        success: function (result) {
            var opts = { "closeButton": true, "debug": false, "positionClass": "toast-top-full-width", "onclick": null, "showDuration": null, "hideDuration": null, "timeOut": null, "extendedTimeOut": null, "showEasing": "swing", "hideEasing": "linear", "showMethod": "fadeIn", "hideMethod": "fadeOut" };
            if (result.Status) {
                toastr.success(result.Message, result.Caption, opts);
                ClearFields();
                GetTable();
            }
            else
                toastr.error(result.Message, result.Caption, opts);

            $(".loadingImg").hide();
        }
    });
}

function GetTable() {
    Table = $('#tblGetRoles').DataTable({
        "processing": true,
        "serverSide": false,
        "paging": true,
        "ordering": true,
        "info": true,
        "searching": true,
        "bFilter": false,
        "scrollX": "100%",
        "scrollY": ($(window).height() - 500),
        "sScrollXInner": "100%",
        "bScrollCollapse": true,
        //"sAjaxSource": '/CPanelDev/GetRolesGrid',
        "ajax": {
            "type": "POST",
            "url": "/CPanelDev/GetRolesGrid",
            "dataSrc": function (data, type, row) {
                if (data.isRedirect)
                    window.location.href = data.URL;
                else
                    return data.aaData;
            }
        },
        "bDestroy": true,
        "bLengthChange": true,
        "bPaginate": true,
        "sEmptyTable": "Loading data from server",

        "columns": [
            { "sWidth": "5%", "sClass": "TextCenter ID", "render": function (data, type, row) { return row[0]; } },
            { "sWidth": "25%", "sClass": "TextCenter Code", "render": function (data, type, row) { return (row[1]); } },
            { "sWidth": "60%", "sClass": "TextCenter Desc", "render": function (data, type, row) { return (row[2]); } },
            {
                "sWidth": "10%",
                "bSortable": false,
                "sClass": "TextCenter",
                "render": function (data, type, row) {
                    return '<center><a href="javascript:void(0);" title="Edit" onclick=EditData(this); return false;> <i class="glyphicon glyphicon-edit"></i></a>&nbsp;&nbsp;<a href="javascript:void(0);" title="Delete"  onclick=DeleteData("' + row[1] + '"); return false;> <i class="glyphicon glyphicon-trash"></i></a></center>';
                }, "targets": 0,
            }
        ],
    });
}

function EditData(row) {
    var Code = $(row).closest('tr').find('.Code').html();
    $('#txtCode').val(Code);

    var Desc = $(row).closest('tr').find('.Desc').html();
    $('#txtDesc').val(Desc);

    $('#txtCode').attr('disabled', true);
    $('#btnSave').val("Update");
}

function ClearFields() {
    $("#txtCode").val("");
    $("#txtDesc").val("");
    $('#btnSave').val("Save");
    $('#txtCode').attr('disabled', false);
}

function DeleteData(code) {
    swal({
        title: "Are you sure?",
        text: "This will delete the Record",
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Yes, Delete it!",
        closeOnConfirm: false
    },
        function (isConfirm) {
            $(".loadingImg").show();
            if (isConfirm) {
                $.ajax({
                    url: '/CPanelDev/DeleteRole',
                    type: 'POST',
                    data: JSON.stringify({ "Code": code }),
                    contentType: 'application/json; charset=utf-8;',
                    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                    success: function (result) {
                        if (result.Status) {
                            swal(result.Message, result.Caption, "success");
                            GetTable();
                        }
                        else
                            swal(result.Message, result.Caption, "error");
                    }
                });
            }
            $(".loadingImg").hide();
        }
    );
}
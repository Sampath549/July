﻿using Application.App_Start;
using Application.Filters;
using Application.Helper;
using Application.Models.SharedEntities;
using Microsoft.Security.Application;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;

namespace Application.Controllers
{
    [MVCSessionFilter, MultiLoginFilter, MVCUserAuthorization]
    public class CPanelUserController : Controller
    {
        #region Dashboard
        public ActionResult Dashboard()
        {
            try
            {
                ViewBag.DisplayModalPopup = Reusable.CheckIsFirstTimeLogin();   // Model PopUp   
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
                return View();
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }
        #endregion

        #region Accommodation
        public ActionResult AccommodationPosts(int? PageNum)
        {
            try
            {
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
                SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
                List<int> _lstNum = new List<int>();
                _lstNum.Add(Convert.ToInt32(PageNum == null ? 1 : PageNum));
                _lstNum.Add(5);
                _lstNum.Add(_SessionUserDetails.UserId);

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_lstNum);
                string response = ApiHelper.PostData_Json("api/CPanelUser/GridAccPosts?Values=", _Array);
                Result<List<SE_Accommodation>> _Result = JsonConvert.DeserializeObject<Result<List<SE_Accommodation>>>(response);
                List_SE_Accommodation _lst = new List_SE_Accommodation();
                _lst.ListAccPosts = _Result.Data;

                return View(_lst);
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }

        public ActionResult ViewAccPosts(int Id)
        {
            try
            {
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus

                SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_SessionUserDetails.UserId.ToString());
                _Array.Add(Id.ToString());

                string response = ApiHelper.PostData_Json("api/CPanelUser/SinglePosts?Values=", _Array);
                Result<ViewPost_Comments> _Result = JsonConvert.DeserializeObject<Result<ViewPost_Comments>>(response);

                SE_Accommodation _Rec = new SE_Accommodation();
                _Rec.FullName = RSAPattern.Decrypt(_Result.Data.ViewPost.FirstName) + " " + RSAPattern.Decrypt(_Result.Data.ViewPost.LastName);
                _Rec.AccommodationId = _Result.Data.ViewPost.AccommodationId;
                _Rec.UserId = _Result.Data.ViewPost.UserId;
                _Rec.Title = _Result.Data.ViewPost.Title;
                _Rec.RoomType = _Result.Data.ViewPost.RoomType;
                _Rec.Address = _Result.Data.ViewPost.Address;
                _Rec.City = _Result.Data.ViewPost.City;
                _Rec.StateDesc = _Result.Data.ViewPost.StateDesc;
                _Rec.CountryDesc = _Result.Data.ViewPost.CountryDesc;
                _Rec.ZipCode = _Result.Data.ViewPost.ZipCode;
                _Rec.Description = _Result.Data.ViewPost.Description;
                _Rec.DateLongString = _Result.Data.ViewPost.DateLongString;
                _Rec.ImagePath = _Result.Data.ViewPost.ImagePath;
                _Rec.ImgType = _Result.Data.ViewPost.ImgType;

                List<SE_Comments> _Comments = new List<SE_Comments>();
                foreach (SE_Comments Val in _Result.Data.CommentsList.ToList())
                {
                    SE_Comments SingleRec = new SE_Comments();
                    SingleRec.CommentId = Val.CommentId;
                    SingleRec.ParentCommentId = Val.ParentCommentId;
                    SingleRec.Comments = Val.Comments;
                    SingleRec.ReplyUserId = Val.ReplyUserId;
                    SingleRec.PageId = Val.PageId;
                    SingleRec.PageColumnId = Val.PageColumnId;
                    SingleRec.ReplyFirstName = RSAPattern.Decrypt(Val.ReplyFirstName);
                    SingleRec.ReplyLastName = RSAPattern.Decrypt(Val.ReplyLastName);
                    SingleRec.ReplyPhoto = Val.ReplyPhoto.ToString();
                    SingleRec.CommentedDate = Val.CommentedDate;
                    SingleRec.FullStringDate = Val.CommentedDate.ToString("ddd, dd MMM yyyy") + ", " + Val.CommentedDate.ToString("hh:mm tt");
                    SingleRec.HavingParentCommentId = Val.HavingParentCommentId;
                    if (SingleRec.HavingParentCommentId)
                    {
                        SingleRec.InnerComments = InnerResult(Val.InnerComments, SingleRec.CommentId);
                    }
                    else
                        SingleRec.InnerComments = new List<SE_Comments>();
                    _Comments.Add(SingleRec);
                }

                ViewPost_Comments _Data = new ViewPost_Comments();
                _Data.ViewPost = _Rec;
                _Data.CommentsList = _Comments;
                _Data.TotalComments = _Result.Data.TotalComments;
                _Data.RawHTML = RawHTMLComments(_Comments);

                return View(_Data);
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }

        public string RawHTMLComments(IEnumerable<SE_Comments> _Comments)
        {

            string str = @"";
            List<SE_Comments> _Result = new List<SE_Comments>();
            foreach (SE_Comments Val in _Comments)
            {
                str += @"<li class='comment'>
                            <div class='comment-body'>
                                <div class='comment-author'>";

                if (Val.ReplyPhoto == "")
                    str += @"<span style = 'border: 1px solid #ccc; border-radius: 50%; float:left; height: 60px; width: 60px; max-width: 100%; margin-bottom:30px;  margin-right:25px; position:relative; color: #337ab7;font-size:38px; font-weight:700; line-height: 52px;text-align:center !important; vertical-align:middle;'>" + Val.ReplyFirstName.Trim().Substring(0, 1) + "</span>";
                else
                    str += @"<img class='avatar' src=" + Val.ReplyPhoto + " alt='Image'>";

                str += @"<span class='fn'>" + Val.ReplyFirstName + ' ' + Val.ReplyLastName + "</span>";
                str += @"</div>";

                str += @"<div class='comment-meta commentmetadata'><a href = '#' >" + Val.FullStringDate + " </a></div>";

                str += @"<div class='comment-content'>
                            <p>" + Val.Comments + "</p></div>";

                str += @"<div class='reply'>
                            <a href = '#' class='btn-link hrefLinkClick' onclick='MyFunc(" + Val.CommentId + ")'><i class='fa fa-reply' aria-hidden='true'></i> Reply</a>";
                str += @"<div id= '" + Val.CommentId + "' class='form-horizontal'></div>";
                str += @"</div></div>";

                if (Val.HavingParentCommentId && Val.InnerComments.Count > 0)
                {
                    str += InnerRawHTMLComments(Val.InnerComments);
                }
                str += " </li>";
            }
            return str;
        }

        public string InnerRawHTMLComments(IEnumerable<SE_Comments> _Comments)
        {
            string str = @"";
            if (_Comments.ToList().Count > 0)
            {
                str += @"<ul class='children'>";
                foreach (SE_Comments IC in _Comments)
                {
                    str += @"<li class='comment'>
                            <div class='comment-body'>
                                <div class='comment-author'>";

                    if (IC.ReplyPhoto == "")
                        str += @"<span style = 'border: 1px solid #ccc; border-radius: 50%; float:left; height: 60px; margin-bottom:30px;  margin-right:25px; position:relative; width: 60px; max-width: 100%; color: #337ab7;font-size:38px; font-weight:700; line-height: 52px;text-align:center !important; vertical-align:middle;'>" + IC.ReplyFirstName.Trim().Substring(0, 1) + "</span>";
                    else
                        str += @"<img class='avatar' src=" + IC.ReplyPhoto + " alt='Image'>";

                    str += @"<span class='fn'>" + IC.ReplyFirstName + ' ' + IC.ReplyLastName + "</span>";
                    str += @"</div>";

                    str += @"<div class='comment-meta commentmetadata'><a href = '#' >" + IC.FullStringDate + " </a></div>";

                    str += @"<div class='comment-content'>
                            <p>" + IC.Comments + "</p></div>";

                    str += @"<div class='reply'>
                            <a href = '#' class='btn-link hrefLinkClick' onclick='MyFunc(" + IC.CommentId + ")'><i class='fa fa-reply' aria-hidden='true'></i> Reply</a>";
                    str += @"<div id= '" + IC.CommentId + "' class='form-horizontal'></div>";
                    str += @"</div></div>";
                    if (IC.HavingParentCommentId && IC.InnerComments.Count > 0)
                    {
                        string InnerStr = InnerRawHTMLComments(IC.InnerComments);
                        str += InnerStr;
                    }
                    str += @"</li>";
                }
                str += " </ul>";
            }
            return str;
        }

        public List<SE_Comments> InnerResult(List<SE_Comments> _Result, int CommentId)
        {
            List<SE_Comments> _InnerResult = new List<SE_Comments>();
            foreach (SE_Comments Val in _Result)
            {
                SE_Comments SingleRec = new SE_Comments();
                if (CommentId == Val.ParentCommentId)
                {
                    SingleRec.CommentId = Val.CommentId;
                    SingleRec.ParentCommentId = Val.ParentCommentId;
                    SingleRec.Comments = Val.Comments;
                    SingleRec.ReplyUserId = Val.ReplyUserId;
                    SingleRec.PageId = Val.PageId;
                    SingleRec.PageColumnId = Val.PageColumnId;
                    SingleRec.ReplyFirstName = RSAPattern.Decrypt(Val.ReplyFirstName);
                    SingleRec.ReplyLastName = RSAPattern.Decrypt(Val.ReplyLastName);
                    SingleRec.ReplyPhoto = Val.ReplyPhoto.ToString();
                    SingleRec.CommentedDate = Val.CommentedDate;
                    SingleRec.FullStringDate = Val.CommentedDate.ToString("ddd, dd MMM yyyy") + ", " + Val.CommentedDate.ToString("hh:mm tt");
                    SingleRec.HavingParentCommentId = Val.HavingParentCommentId;
                    SingleRec.InnerComments = InnerResult(Val.InnerComments, SingleRec.CommentId);

                    _InnerResult.Add(SingleRec);
                }
            }
            return _InnerResult;
        }

        public ActionResult AddedAccPosts()
        {
            try
            {
                var model = new SE_Menus();
                ArrayList _Array = new ArrayList();

                ViewBag.AccPRoomTypes = Reusable.RoomTypes();
                ViewBag.AccPStates = Reusable.StatesList();
                ViewBag.AccPCountries = Reusable.CountriesList();

                return View("../PartialViews/AddAccPosts");
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult InsertAccPosts(SE_Accommodation _Posts)
        {
            try
            {
                //Server-Side Validations
                if (_Posts.Title == null || Sanitizer.GetSafeHtmlFragment(_Posts.Title) == "" || Sanitizer.GetSafeHtmlFragment(_Posts.Title).Length > 50 || Sanitizer.GetSafeHtmlFragment(_Posts.Title).Length < 5)
                    return Json(new Result(false, 500, "Validation Error", "Title should not be Empty and must have Min of 5 & Max of 50 Characters"), JsonRequestBehavior.AllowGet);
                if (_Posts.RoomType == null || Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Posts.RoomType)) == "")
                    return Json(new Result(false, 500, "Validation Error", "Please Select Parent Menu"), JsonRequestBehavior.AllowGet);
                if (_Posts.Address == null || Sanitizer.GetSafeHtmlFragment(_Posts.Address) == "" || Sanitizer.GetSafeHtmlFragment(_Posts.Address).Length > 50 || Sanitizer.GetSafeHtmlFragment(_Posts.Address).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Address should not be Empty and must have Min of 3 & Max of 50 Characters"), JsonRequestBehavior.AllowGet);
                if (_Posts.City == null || Sanitizer.GetSafeHtmlFragment(_Posts.City) == "" || Sanitizer.GetSafeHtmlFragment(_Posts.City).Length > 30 || Sanitizer.GetSafeHtmlFragment(_Posts.City).Length < 2)
                    return Json(new Result(false, 500, "Validation Error", "City should not be Empty and must have Min of 2 & Max of 30 Characters"), JsonRequestBehavior.AllowGet);
                if (_Posts.StateId == null || Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Posts.StateId)) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Posts.StateId)), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "Please Select Parent Menu"), JsonRequestBehavior.AllowGet);
                if (_Posts.CountryId == null || Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Posts.CountryId)) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Posts.CountryId)), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "Please Select Parent Menu"), JsonRequestBehavior.AllowGet);
                if (_Posts.ZipCode == null || Sanitizer.GetSafeHtmlFragment(_Posts.ZipCode) == "" || Sanitizer.GetSafeHtmlFragment(_Posts.ZipCode).Length > 5 || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Posts.ZipCode)), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "ZipCode should not be Empty and must contain only Numbers with Max of 5 Characters"), JsonRequestBehavior.AllowGet);
                if (_Posts.Description == null || Sanitizer.GetSafeHtmlFragment(_Posts.Description) == "" || Sanitizer.GetSafeHtmlFragment(_Posts.Description).Length > 300 || Sanitizer.GetSafeHtmlFragment(_Posts.Description).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Description should not be Empty and must have Min of 3 & Max of 300 Characters"), JsonRequestBehavior.AllowGet);
                if (_Posts.ImagePath != null)
                {
                    List<string> _ext = Reusable.ProfilePicExtentions();
                    if (!_ext.Contains(_Posts.ImgType))
                        return Json(new Result(false, 500, "Validation Error", "Upload Images of Extentions .JPG, .JPEG, .PNG"), JsonRequestBehavior.AllowGet);
                }

                SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
                _Posts.UserId = _SessionUserDetails.UserId;

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Posts);
                string response = ApiHelper.PostData_Json("api/CPanelUser/InsertAccPosts?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Json(new Result<bool>(false, false, 500, GlobalVariables.Shared.InternalServerErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult DeleteAccPost(int DeleteAccPostID)
        {
            try
            {
                //Server-Side Validations
                if (Sanitizer.GetSafeHtmlFragment(DeleteAccPostID.ToString()) == "" || Sanitizer.GetSafeHtmlFragment(DeleteAccPostID.ToString()).Length > 10 || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Convert.ToString(DeleteAccPostID)), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "Validation Error"), JsonRequestBehavior.AllowGet);

                SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
                List<string> _Val = new List<string>();
                _Val.Add(_SessionUserDetails.UserId.ToString());
                _Val.Add(DeleteAccPostID.ToString());

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Val);

                string response = ApiHelper.PostData_Json("api/CPanelUser/DeleteAccPosts?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Json(new Result<bool>(false, false, 500, GlobalVariables.Shared.InternalServerErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult InsertComments(string Comments, string PageColumnId, string PageId)
        {
            try
            {
                //Server-Side Validations
                if (Comments == null || Sanitizer.GetSafeHtmlFragment(Comments) == "" || Sanitizer.GetSafeHtmlFragment(Comments).Length > 500 || Sanitizer.GetSafeHtmlFragment(Comments).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Comment should not be Empty and must have Min of 3 & Max of 500 Characters"), JsonRequestBehavior.AllowGet);

                SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;

                List<string> _Values = new List<string>();
                _Values.Add(Comments);
                _Values.Add(PageColumnId.ToString());
                _Values.Add(PageId.ToString());
                _Values.Add(_SessionUserDetails.UserId.ToString());
                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Values);
                string response = ApiHelper.PostData_Json("api/CPanelUser/InsertComments?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Json(new Result<bool>(false, false, 500, GlobalVariables.Shared.InternalServerErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult InsertReplyComments(string Comments, string PageColumnId, string PageId, string ParentCommentId)
        {
            try
            {
                if (PageId == "AccRequests")
                    PageId = "AccPosts";

                //Server-Side Validations
                if (Comments == null || Sanitizer.GetSafeHtmlFragment(Comments) == "" || Sanitizer.GetSafeHtmlFragment(Comments).Length > 500 || Sanitizer.GetSafeHtmlFragment(Comments).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Comment should not be Empty and must have Min of 3 & Max of 500 Characters"), JsonRequestBehavior.AllowGet);

                SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;

                List<string> _Values = new List<string>();
                _Values.Add(Comments);
                _Values.Add(PageColumnId.ToString());
                _Values.Add(PageId.ToString());
                _Values.Add(_SessionUserDetails.UserId.ToString());
                _Values.Add(ParentCommentId);

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Values);
                string response = ApiHelper.PostData_Json("api/CPanelUser/InsertReplyComments?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Json(new Result<bool>(false, false, 500, GlobalVariables.Shared.InternalServerErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult AccommodationRequests()
        {
            try
            {
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
                return View();
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }

        public JsonResult GetAccRequests()
        {
            List<SE_Accommodation> _list = new List<SE_Accommodation>();
            try
            {
                SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
                ArrayList _Array = new ArrayList();
                _Array.Add(_SessionUserDetails.UserId.ToString());

                string _Roles = ApiHelper.PostData_Json("api/CPanelUser/GetAccRequests?Values=", _Array);
                Result<List<SE_Accommodation>> _ResultRoles = JsonConvert.DeserializeObject<Result<List<SE_Accommodation>>>(_Roles);

                _list = _ResultRoles.Data;
                var result = from c in _list
                             select new[]
                             {
                                 Convert.ToString( c.AccommodationId ),          // 0   
                                 Convert.ToString( c.Title ),        // 1   
                                 Convert.ToString( c.TotalComments),  // 2     
                             };

                return Json(new { aaData = result, URL = "", isRedirect = false }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Json(new Result<bool>(false, false, 500, GlobalVariables.Shared.InternalServerErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult ViewAccRequests(int Id)
        {
            try
            {
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus

                SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_SessionUserDetails.UserId.ToString());
                _Array.Add(Id.ToString());

                string response = ApiHelper.PostData_Json("api/CPanelUser/SingleRequests?Values=", _Array);
                Result<ViewPost_Comments> _Result = JsonConvert.DeserializeObject<Result<ViewPost_Comments>>(response);

                SE_Accommodation _Rec = new SE_Accommodation();
                _Rec.FullName = RSAPattern.Decrypt(_Result.Data.ViewPost.FirstName) + " " + RSAPattern.Decrypt(_Result.Data.ViewPost.LastName);
                _Rec.AccommodationId = _Result.Data.ViewPost.AccommodationId;
                _Rec.UserId = _Result.Data.ViewPost.UserId;
                _Rec.Title = _Result.Data.ViewPost.Title;
                _Rec.RoomType = _Result.Data.ViewPost.RoomType;
                _Rec.Address = _Result.Data.ViewPost.Address;
                _Rec.City = _Result.Data.ViewPost.City;
                _Rec.StateDesc = _Result.Data.ViewPost.StateDesc;
                _Rec.CountryDesc = _Result.Data.ViewPost.CountryDesc;
                _Rec.ZipCode = _Result.Data.ViewPost.ZipCode;
                _Rec.Description = _Result.Data.ViewPost.Description;
                _Rec.DateLongString = _Result.Data.ViewPost.DateLongString;
                _Rec.ImagePath = _Result.Data.ViewPost.ImagePath;
                _Rec.ImgType = _Result.Data.ViewPost.ImgType;

                List<SE_Comments> _Comments = new List<SE_Comments>();
                foreach (SE_Comments Val in _Result.Data.CommentsList.ToList())
                {
                    SE_Comments SingleRec = new SE_Comments();
                    SingleRec.CommentId = Val.CommentId;
                    SingleRec.ParentCommentId = Val.ParentCommentId;
                    SingleRec.Comments = Val.Comments;
                    SingleRec.ReplyUserId = Val.ReplyUserId;
                    SingleRec.PageId = Val.PageId;
                    SingleRec.PageColumnId = Val.PageColumnId;
                    SingleRec.ReplyFirstName = RSAPattern.Decrypt(Val.ReplyFirstName);
                    SingleRec.ReplyLastName = RSAPattern.Decrypt(Val.ReplyLastName);
                    SingleRec.ReplyPhoto = Val.ReplyPhoto.ToString();
                    SingleRec.CommentedDate = Val.CommentedDate;
                    SingleRec.FullStringDate = Val.CommentedDate.ToString("ddd, dd MMM yyyy") + ", " + Val.CommentedDate.ToString("hh:mm tt");
                    SingleRec.HavingParentCommentId = Val.HavingParentCommentId;
                    if (SingleRec.HavingParentCommentId)
                    {
                        SingleRec.InnerComments = InnerResult(Val.InnerComments, SingleRec.CommentId);
                    }
                    else
                        SingleRec.InnerComments = new List<SE_Comments>();
                    _Comments.Add(SingleRec);
                }

                ViewPost_Comments _Data = new ViewPost_Comments();
                _Data.ViewPost = _Rec;
                _Data.CommentsList = _Comments;
                _Data.TotalComments = _Result.Data.TotalComments;
                _Data.RawHTML = RawHTMLComments(_Comments);

                return View(_Data);
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }
        #endregion

        #region BuySell
        public ActionResult BuySellPosts(int? PageNum)
        {
            try
            {
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
                SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
                List<int> _lstNum = new List<int>();
                _lstNum.Add(Convert.ToInt32(PageNum == null ? 1 : PageNum));
                _lstNum.Add(5);
                _lstNum.Add(_SessionUserDetails.UserId);

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_lstNum);
                string response = ApiHelper.PostData_Json("api/CPanelUser/GridBuySellPosts?Values=", _Array);
                Result<List<SE_BuySell>> _Result = JsonConvert.DeserializeObject<Result<List<SE_BuySell>>>(response);
                List_SE_BuySell _lst = new List_SE_BuySell();
                _lst.ListBuySellPosts = _Result.Data;

                return View(_lst);
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }

        public ActionResult AddedBuySellPosts()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            try
            {
                var model = new SE_Menus();
                ArrayList _Array = new ArrayList();
                ViewBag.AccPStates = Reusable.StatesList();
                ViewBag.AccPCountries = Reusable.CountriesList();
                ViewBag.MobileNum = _SessionUserDetails.Mobile;

                return View("../PartialViews/AddBuySellPosts");
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult InsertBuySellPosts(SE_BuySell _Posts)
        {
            try
            {
                //Server-Side Validations
                if (_Posts.Title == null || Sanitizer.GetSafeHtmlFragment(_Posts.Title) == "" || Sanitizer.GetSafeHtmlFragment(_Posts.Title).Length > 50 || Sanitizer.GetSafeHtmlFragment(_Posts.Title).Length < 5)
                    return Json(new Result(false, 500, "Validation Error", "Title should not be Empty and must have Min of 5 & Max of 50 Characters"), JsonRequestBehavior.AllowGet);
                if (_Posts.City == null || Sanitizer.GetSafeHtmlFragment(_Posts.City) == "" || Sanitizer.GetSafeHtmlFragment(_Posts.City).Length > 30 || Sanitizer.GetSafeHtmlFragment(_Posts.City).Length < 2)
                    return Json(new Result(false, 500, "Validation Error", "City should not be Empty and must have Min of 2 & Max of 30 Characters"), JsonRequestBehavior.AllowGet);
                if (_Posts.StateId == null || Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Posts.StateId)) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Posts.StateId)), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "Please Select Parent Menu"), JsonRequestBehavior.AllowGet);
                if (_Posts.CountryId == null || Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Posts.CountryId)) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Posts.CountryId)), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "Please Select Parent Menu"), JsonRequestBehavior.AllowGet);
                if (_Posts.ZipCode == null || Sanitizer.GetSafeHtmlFragment(_Posts.ZipCode) == "" || Sanitizer.GetSafeHtmlFragment(_Posts.ZipCode).Length > 10 || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Posts.ZipCode)), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "ZipCode should not be Empty and must contain only Numbers with Max of 10 Characters"), JsonRequestBehavior.AllowGet);
                if (_Posts.Description == null || Sanitizer.GetSafeHtmlFragment(_Posts.Description) == "" || Sanitizer.GetSafeHtmlFragment(_Posts.Description).Length > 300 || Sanitizer.GetSafeHtmlFragment(_Posts.Description).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Description should not be Empty and must have Min of 3 & Max of 300 Characters"), JsonRequestBehavior.AllowGet);
                if (_Posts.Images != null)
                {
                    if (_Posts.Images.Count > 1)
                        return Json(new Result(false, 500, "Validation Error", "Not more than 1 Image can be Uploaded"), JsonRequestBehavior.AllowGet);
                    else
                    {
                        List<string> _ext = Reusable.ProfilePicExtentions();
                        foreach (var val in _Posts.Images)
                        {
                            if (!_ext.Contains(val.ImgType))
                                return Json(new Result(false, 500, "Validation Error", "Upload Images of Extentions .JPG, .JPEG, .PNG"), JsonRequestBehavior.AllowGet);
                        }
                    }
                }

                SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
                _Posts.UserId = _SessionUserDetails.UserId;

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Posts);
                string response = ApiHelper.PostData_Json("api/CPanelUser/InsertBuySellPosts?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Json(new Result<bool>(false, false, 500, GlobalVariables.Shared.InternalServerErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult ViewBuySellPosts(int Id)
        {
            try
            {
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus

                SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_SessionUserDetails.UserId.ToString());
                _Array.Add(Id.ToString());

                string response = ApiHelper.PostData_Json("api/CPanelUser/SingleBSPosts?Values=", _Array);
                Result<ViewBSPost_Comments> _Result = JsonConvert.DeserializeObject<Result<ViewBSPost_Comments>>(response);

                SE_BuySell _Rec = new SE_BuySell();
                _Rec.FullName = RSAPattern.Decrypt(_Result.Data.ViewBSPost.FirstName) + " " + RSAPattern.Decrypt(_Result.Data.ViewBSPost.LastName);
                _Rec.BuySellId = _Result.Data.ViewBSPost.BuySellId;
                _Rec.UserId = _Result.Data.ViewBSPost.UserId;
                _Rec.Title = _Result.Data.ViewBSPost.Title;
                _Rec.DisplayMobile = _Result.Data.ViewBSPost.DisplayMobile;
                _Rec.Mobile = _SessionUserDetails.Mobile.ToString();
                _Rec.City = _Result.Data.ViewBSPost.City;
                _Rec.StateDesc = _Result.Data.ViewBSPost.StateDesc;
                _Rec.CountryDesc = _Result.Data.ViewBSPost.CountryDesc;
                _Rec.ZipCode = _Result.Data.ViewBSPost.ZipCode;
                _Rec.Description = _Result.Data.ViewBSPost.Description;
                _Rec.DateLongString = _Result.Data.ViewBSPost.DateLongString;
                _Rec.ImagePath = _Result.Data.ViewBSPost.ImagePath;
                _Rec.ImgType = _Result.Data.ViewBSPost.ImgType;

                List<SE_Comments> _Comments = new List<SE_Comments>();
                foreach (SE_Comments Val in _Result.Data.CommentsList.ToList())
                {
                    SE_Comments SingleRec = new SE_Comments();
                    SingleRec.CommentId = Val.CommentId;
                    SingleRec.ParentCommentId = Val.ParentCommentId;
                    SingleRec.Comments = Val.Comments;
                    SingleRec.ReplyUserId = Val.ReplyUserId;
                    SingleRec.PageId = Val.PageId;
                    SingleRec.PageColumnId = Val.PageColumnId;
                    SingleRec.ReplyFirstName = RSAPattern.Decrypt(Val.ReplyFirstName);
                    SingleRec.ReplyLastName = RSAPattern.Decrypt(Val.ReplyLastName);
                    SingleRec.ReplyPhoto = Val.ReplyPhoto.ToString();
                    SingleRec.CommentedDate = Val.CommentedDate;
                    SingleRec.FullStringDate = Val.CommentedDate.ToString("ddd, dd MMM yyyy") + ", " + Val.CommentedDate.ToString("hh:mm tt");
                    SingleRec.HavingParentCommentId = Val.HavingParentCommentId;
                    if (SingleRec.HavingParentCommentId)
                    {
                        SingleRec.InnerComments = InnerResult(Val.InnerComments, SingleRec.CommentId);
                    }
                    else
                        SingleRec.InnerComments = new List<SE_Comments>();
                    _Comments.Add(SingleRec);
                }

                ViewBSPost_Comments _Data = new ViewBSPost_Comments();
                _Data.ViewBSPost = _Rec;
                _Data.CommentsList = _Comments;
                _Data.TotalComments = _Result.Data.TotalComments;
                _Data.RawHTML = RawHTMLComments(_Comments);

                return View(_Data);
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }
        #endregion

    }
}
﻿using Application.Helper;
using Application.Models.DataObjects;
using Application.Models.SharedEntities;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Application.Controllers.API
{
    [RoutePrefix("api/UserPresentation")]
    public class UserPresentationApiController : ApiController
    {
        #region Global Variables
        CPanelUserDAL _ObjCPanelUser = new CPanelUserDAL();
        #endregion

        [HttpPost, Route("GridAccPosts")]
        public Result<List<SE_Accommodation>> GridAccPosts(ArrayList Array)
        {
            List<int> _lstPage = new List<int>();
            List<SE_Accommodation> _Result = new List<SE_Accommodation>();
            try
            {
                foreach (JArray val in Array)
                    _lstPage = val.ToObject<List<int>>();

                _Result = _ObjCPanelUser.GridAccPosts(_lstPage[0], _lstPage[1], null);
                return Result.Success(_Result, 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(_Result, 500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("InsertComments")]
        public Result InsertComments(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            try
            {
                foreach (JArray val in Array)
                    _lst = val.ToObject<List<string>>();

                int _Result = _ObjCPanelUser.InsertComments(_lst[0], Convert.ToInt32(_lst[1]), _lst[2], Convert.ToInt32(_lst[3]));

                if (_Result == 1)
                    return Result.Success(200, "Success", "Comment Posted Succesfully");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("InsertReplyComments")]
        public Result InsertReplyComments(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            try
            {
                foreach (JArray val in Array)
                    _lst = val.ToObject<List<string>>();

                int _Result = _ObjCPanelUser.InsertReplyComments(_lst[0], Convert.ToInt32(_lst[1]), _lst[2], Convert.ToInt32(_lst[3]), Convert.ToInt32(_lst[4]));

                if (_Result == 1)
                    return Result.Success(200, "Success", "Comment Posted Succesfully");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }
    }
}

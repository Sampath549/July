﻿using Application.Helper;
using Application.Models.DataObjects;
using Application.Models.SharedEntities;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Application.Controllers.API
{
    [RoutePrefix("api/CPanel")]
    public class CPanelApiController : ApiController
    {
        SE_Users Users;
        TokenDAL _ObjToken = new TokenDAL();
        SharedDAL _ObjShared = new SharedDAL();
        CPanelDAL _ObjCPanel = new CPanelDAL();

        [HttpPost, Route("Registration")]
        public Result Registration(ArrayList Array)
        {
            try
            {
                Users = new SE_Users();
                foreach (JObject val in Array)
                    Users = val.ToObject<SE_Users>();

                string ActualFName, ActualLName, ActualEmail, ActualMobile, RandomPwd, SaltKey = string.Empty;
                ActualFName = RSAPattern.Decrypt(Users.FirstName);
                ActualLName = RSAPattern.Decrypt(Users.LastName);
                ActualEmail = RSAPattern.Decrypt(Users.Email);
                ActualMobile = RSAPattern.Decrypt(Users.Mobile);
                RandomPwd = PasswordEncryption.GeneratePassword();
                SaltKey = PasswordEncryption.GeneratePassword();

                Users.PersonalKey = AES_Algorithm.EncryptString(Guid.NewGuid().ToString());
                Users.FirstName = AES_Algorithm.EncryptString(ActualFName);
                Users.LastName = AES_Algorithm.EncryptString(ActualLName);
                Users.Email = SymmetricAlgorithm.Encrypt(ActualEmail);
                Users.Mobile = SymmetricAlgorithm.Encrypt(ActualMobile);
                Users.RoleCode = GlobalVariables.Shared.UserRole;
                Users.SaltKey = AES_Algorithm.EncryptString(SaltKey);
                Users.Password = PasswordEncryption.EncodePassword(RandomPwd, SaltKey);

                int _Status = _ObjCPanel.InsertRegistration(Users);

                bool _SendMail = false;
                if (_Status == 1)
                {
                    EmailSender _EmailHelper = EmailSender.Instance;
                    string _MessageBody = @"<div id='Template' width='100%' height=450'>
                                            <p>Dear <b>" + ActualFName + @" " + ActualLName + @"</b>..!!,</p>
                                            <p>Thank you for Joining EuroBharat. Here are the details.</p>
                                            <div style='margin-left:40px; color:initial;'>
                                            <table style='border:0'>
                                                <tr>
                                                    <td style='border:0'> Email:</td>
                                                    <td style='border:0'><strong>" + ActualEmail + @"</strong></td>
                                                </tr>
                                                <tr>
                                                    <td style='border:0'> Password:</td>
                                                    <td style='border:0'><strong>" + RandomPwd + @"</strong></td>
                                                </tr>
                                            </table>
                                        </div>
                                        <br/>
                                        <p style='margin-bottom: 0px'><strong> Important Note :</strong></p>
                                        <div style='margin-left:40px; margin-top: -15px; color:initial;'>
                                            <table style = 'border:0'>
                                                <tr>
                                                    <td style='border:0'>a. Please find the attached file for better understanding of EuroBharat.</td>
                                                </tr>
                                            </table>
                                        </div>
                                        <br/>
                                    </div>";
                    List<EmailAttachment> _Attachments = new List<EmailAttachment>();
                    _Attachments.Add(new EmailAttachment("Welcome.pdf", File.ReadAllBytes(System.Web.Hosting.HostingEnvironment.MapPath("~/Helper/Documents/Welcome.pdf"))));

                    if (!GlobalVariables.Shared.DontSendMail)
                    {
                        string emailTo = string.Empty;
                        if (GlobalVariables.Shared.SendActualMails)
                            emailTo = ActualEmail;
                        else
                            emailTo = GlobalVariables.Shared.SendDefaultEmailTo;

                        _SendMail = _EmailHelper.SendWithTemplate(emailTo, "", "Welcome Email", _EmailHelper.HTMLSanitize(_MessageBody), _Attachments);
                    }
                    else
                        _SendMail = true;

                    if (GlobalVariables.Shared.SavePasswords)
                        Reusable.SaveTempPasswords(ActualEmail, RandomPwd, SaltKey);
                }

                if (_Status == 1 && _SendMail == false)
                    return Result.Failed(500, GlobalVariables.Shared.RegistrationSuccessMailErrorMsg, GlobalVariables.Shared.EmailFailedMsg);
                else if (_Status == 101)
                    return Result.Failed(500, GlobalVariables.Shared.DuplicateMailMobileMsg, GlobalVariables.Shared.DuplicateRecMsg);
                else
                    return Result.Success(200, GlobalVariables.Shared.RegistrationSuccessMsg, GlobalVariables.Shared.SuccessMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("ForgotPasswordLink")]
        public Result ForgotPasswordLink(ArrayList Array)
        {
            List<string> _Val = new List<string>();
            try
            {
                foreach (string val in Array)
                    _Val.Add(RSAPattern.Decrypt(val.ToString()));

                string ActualEmail = string.Empty;
                ActualEmail = _Val[0];

                string DBEmail = SymmetricAlgorithm.Encrypt(_Val[0]);
                //_Val.TextValue = StringEncrypt.Encrypt(ActualEmail);

                string GuidVal = AES_Algorithm.EncryptString(Guid.NewGuid().ToString().Trim());
                string _Status = _ObjShared.GetFullNameByEmail(DBEmail);

                bool _SendMail = false;
                if (_Status != null)
                {
                    int ResetLog = _ObjCPanel.InsertResetPwdLog(GuidVal, DBEmail);
                    if (ResetLog == 0)
                        return Result.Failed(500, "Error", "Internal Server Error");
                    if (ResetLog == 201)
                        return Result.Failed(500, "Duplicate Submission", "Reset Password Link has been already sent. Please wait for sometime and retry again.");

                    string[] FullName = _Status.Split('^');
                    string URL = GlobalVariables.Shared.ConfigUrl + GlobalVariables.Shared.ResetPwdURL + GuidVal;
                    EmailSender _EmailSender = EmailSender.Instance;
                    string _MessageBody = @"<div id='Template' width='100%' height=450'>
                                            <p>Dear <b>" + AES_Algorithm.DecryptString(FullName[0]) + @" " + AES_Algorithm.DecryptString(FullName[1]) + @"</b>!!,</p>
                                            <p>We have created a link to Reset your Password. Please click on the below Link</p>
                                            <div style='margin-left:40px; color:initial;'>
                                            <table style='border:0'>
                                                <tr>
                                                    <td style='border:0'><strong><a href=" + URL + @">Click Here</a></strong></td>
                                                </tr>
                                            </table>
                                        </div>
                                        <br/>
                                    </div>";
                    List<EmailAttachment> _Attachments = new List<EmailAttachment>();

                    if (!GlobalVariables.Shared.DontSendMail)
                    {
                        string emailTo = string.Empty;
                        if (GlobalVariables.Shared.SendActualMails)
                            emailTo = ActualEmail;
                        else
                            emailTo = GlobalVariables.Shared.SendDefaultEmailTo;

                        _SendMail = _EmailSender.SendWithTemplate(emailTo, "", "Reset Password", _EmailSender.HTMLSanitize(_MessageBody), _Attachments);
                    }
                    else
                        _SendMail = true;

                    if (GlobalVariables.Shared.SavePasswords)
                        Reusable.SaveResetPwdLink(ActualEmail, AES_Algorithm.DecryptString(FullName[0]) + " " + AES_Algorithm.DecryptString(FullName[1]), URL);
                }
                else
                    return Result.Success(200, "Reset Password Link has been sent to your Registered email", GlobalVariables.Shared.SuccessMsg);

                if (_SendMail)
                    return Result.Success(200, "Reset Password Link has been sent to your Registered email", GlobalVariables.Shared.SuccessMsg);
                else
                    return Result.Failed(500, GlobalVariables.Shared.InternalServerErrorMsg, GlobalVariables.Shared.ValidationErrorMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpGet, Route("GetLinkExpiryTime")]
        public string GetLinkExpiryTime(string StringVal)
        {
            try
            {
                return _ObjCPanel.GetExpiryDate_IsReset(StringVal.Replace(" ", "+"));
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return null;
            }
        }

        [HttpPost, Route("ResetPassword")]
        public Result ResetPassword(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            try
            {
                foreach (JArray val in Array)
                    _lst = val.ToObject<List<string>>();

                string ActualEmail, EmailEncrypt = string.Empty;
                ActualEmail = RSAPattern.Decrypt(_lst[0]);
                EmailEncrypt = SymmetricAlgorithm.Encrypt(ActualEmail);

                string SaltKey = PasswordEncryption.GeneratePassword();
                string NewPassword = PasswordEncryption.EncodePassword(RSAPattern.Decrypt(_lst[1]), SaltKey);
                string NewSaltKey = AES_Algorithm.EncryptString(SaltKey);

                int _Result = _ObjCPanel.ResetPassword(EmailEncrypt, NewPassword, NewSaltKey, _lst[2]);
                if (_Result == 1)
                    return Result.Success(200, "Email Sent Succesfully", GlobalVariables.Shared.SuccessMsg);
                else if (_Result == 99)
                    return Result.Failed(500, "Link Expired", GlobalVariables.Shared.ValidationErrorMsg);
                else if (_Result == 100)
                    return Result.Failed(500, "Password Already Updated", GlobalVariables.Shared.ValidationErrorMsg);
                else
                    return Result.Failed(500, GlobalVariables.Shared.InternalServerErrorMsg, GlobalVariables.Shared.ValidationErrorMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("Audit")]
        public Result<SE_Users> Audit(ArrayList ArrayAudit)
        {
            Users = new SE_Users();
            SE_Users _Result = new SE_Users();
            try
            {
                foreach (JObject val in ArrayAudit)
                    Users = val.ToObject<SE_Users>();

                string ActualEmail = RSAPattern.Decrypt(Users.Email);
                bool _Status = Convert.ToBoolean(_ObjToken.TokenAuthentication(ActualEmail, RSAPattern.Decrypt(Users.Password)).Status);
                int UserIdEmail = _ObjShared.GetUserIdByEmail(SymmetricAlgorithm.Encrypt(ActualEmail));

                bool AuditRec = _ObjCPanel.InsertAuditLogin(UserIdEmail, UserIdEmail > 0 ? null : SymmetricAlgorithm.Encrypt(ActualEmail), Users.IPAddress, Users.EntryType, Users.EntryFrom, Users.BrowserName + " " + Users.BrowserVersion, Users.ResolutionWidth + "x" + Users.ResolutionHeight, Users.Location, Users.Latitude, Users.Longitude, _Status);
                if (!_Status && AuditRec)
                    _ObjCPanel.UpdateAttemptsFailed(UserIdEmail);

                return Result.Success(_Result, 200, GlobalVariables.Shared.SuccessMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(_Result, 500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("LoginAuthentication")]
        public Result<SE_Users> LoginAuthentication(ArrayList Array)
        {
            SE_Users _Result = new SE_Users();
            try
            {
                List<string> Users = new List<string>();
                foreach (string val in Array)
                    Users.Add(val.ToString());

                string ActualEmail = RSAPattern.Decrypt(Users[0]);
                _Result = _ObjCPanel.AuthenticatedUser(SymmetricAlgorithm.Encrypt(ActualEmail), PasswordEncryption.EncodePassword(RSAPattern.Decrypt(Users[1]), AES_Algorithm.DecryptString(_ObjShared.GetSaltKeyByEmail(SymmetricAlgorithm.Encrypt(ActualEmail)))));
                _Result.RedirectUrl = Reusable.RedirectPage(_Result.RoleCode);
                if (_Result.RedirectUrl.ToString() != "")
                {
                    _Result.FirstName = RSAPattern.Encrypt(AES_Algorithm.DecryptString(_Result.FirstName));
                    _Result.LastName = RSAPattern.Encrypt(AES_Algorithm.DecryptString(_Result.LastName));
                    _Result.Email = RSAPattern.Encrypt(SymmetricAlgorithm.Decrypt(_Result.Email));
                    _Result.Mobile = RSAPattern.Encrypt(SymmetricAlgorithm.Decrypt(_Result.Mobile));

                    return Result.Success(_Result, 200, GlobalVariables.Shared.SuccessMsg);
                }
                else
                    return Result.Failed(_Result, 500, GlobalVariables.Shared.InvalidUserPasswordMsg, GlobalVariables.Shared.ValidationErrorMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(_Result, 500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("MultiLogin")]
        public Result<int> MultiLogin(ArrayList Array)
        {
            int _Status = 0;
            try
            {
                List<string> _Rec = new List<string>();
                foreach (string val in Array)
                    _Rec.Add(RSAPattern.Decrypt(val.ToString()));

                _Status = _ObjCPanel.InsertMultiLogin(SymmetricAlgorithm.Encrypt(_Rec[0]), _Rec[1], _Rec[2]);
                return Result.Success(_Status, 200, GlobalVariables.Shared.SuccessMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(_Status, 500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Authorize, Route("LogoutMultiLogin")]
        public Result<int> LogoutMultiLogin(ArrayList Array)
        {
            int _Status = 0;
            try
            {
                List<string> _Rec = new List<string>();
                foreach (string val in Array)
                    _Rec.Add(RSAPattern.Decrypt(val.ToString()));

                _Status = _ObjCPanel.UpdateMultiLogin(SymmetricAlgorithm.Encrypt(_Rec[0]));
                return Result.Success(_Status, 200, GlobalVariables.Shared.SuccessMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(_Status, 500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("LogoutMultiLoginIfNull")]
        public Result<int> LogoutMultiLoginIfNull(ArrayList Array)
        {
            int _Status = 0;
            try
            {
                List<string> _Rec = new List<string>();
                foreach (string val in Array)
                    _Rec.Add(RSAPattern.Decrypt(val.ToString()));

                _Status = _ObjCPanel.UpdateMultiLogin(SymmetricAlgorithm.Encrypt(_Rec[0]));
                return Result.Success(_Status, 200, GlobalVariables.Shared.SuccessMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(_Status, 500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Authorize, Route("BindMenus")]
        public Result<string> BindMenus(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            try
            {
                foreach (string val in Array)
                    _lst.Add(val.ToString());

                string _Result = _ObjCPanel.GetMenus(RSAPattern.Decrypt(_lst[0]));
                _Result = _Result.Replace(Environment.NewLine, string.Empty).Trim();

                return Result.Success(_Result, 200, GlobalVariables.Shared.SuccessMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed("", 500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("OneTimePassword")]
        public Result OneTimePassword(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            try
            {
                foreach (JArray val in Array)
                    _lst = val.ToObject<List<string>>();

                string OldPassword, OldSaltKey, Password = string.Empty;
                Password = RSAPattern.Decrypt(_lst[1]);
                OldSaltKey = _ObjShared.GetSaltKeyById(RSAPattern.Decrypt(_lst[2]));
                OldPassword = PasswordEncryption.EncodePassword(RSAPattern.Decrypt(_lst[0]), AES_Algorithm.DecryptString(OldSaltKey));

                string SaltKey = PasswordEncryption.GeneratePassword();
                string NewPassword = PasswordEncryption.EncodePassword(RSAPattern.Decrypt(_lst[1]), SaltKey);
                string NewSaltKey = AES_Algorithm.EncryptString(SaltKey);

                int _Result = _ObjCPanel.OneTimePassword(Convert.ToInt32(RSAPattern.Decrypt(_lst[2])), OldPassword, OldSaltKey, NewPassword, NewSaltKey);

                if (_Result == 1)
                    return Result.Success(200, GlobalVariables.Shared.ChangePwdSuccessMsg, GlobalVariables.Shared.SuccessMsg);
                else if (_Result == 99)
                    return Result.Failed(500, GlobalVariables.Shared.IncorrectOldPwdMsg, GlobalVariables.Shared.ValidationErrorMsg);
                else
                    return Result.Failed(500, GlobalVariables.Shared.InternalServerErrorMsg, GlobalVariables.Shared.ValidationErrorMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("MyProfileDetails")]
        public Result<SE_MyProfile> MyProfileDetails(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            SE_MyProfile _Result = new SE_MyProfile();
            try
            {
                foreach (string val in Array)
                    _lst.Add(val.ToString());

                string ActualEmail = SymmetricAlgorithm.Encrypt(RSAPattern.Decrypt(_lst[0]));
                _Result = _ObjCPanel.MyProfileDetails(ActualEmail);

                if (_Result.Gender != null)
                    _Result.Gender = RSAPattern.Encrypt(AES_Algorithm.DecryptString(_Result.Gender));
                if (_Result.PAddress != null)
                    _Result.PAddress = RSAPattern.Encrypt(AES_Algorithm.DecryptString(_Result.PAddress));
                if (_Result.PCity != null)
                    _Result.PCity = RSAPattern.Encrypt(AES_Algorithm.DecryptString(_Result.PCity));
                if (_Result.PZipCode != null)
                    _Result.PZipCode = RSAPattern.Encrypt(_Result.PZipCode);
                if (_Result.CAddress != null)
                    _Result.CAddress = RSAPattern.Encrypt(AES_Algorithm.DecryptString(_Result.CAddress));
                if (_Result.CCity != null)
                    _Result.CCity = RSAPattern.Encrypt(AES_Algorithm.DecryptString(_Result.CCity));
                if (_Result.CZipCode != null)
                    _Result.CZipCode = RSAPattern.Encrypt(_Result.CZipCode);

                return Result.Success(_Result, 200, GlobalVariables.Shared.SuccessMsg, GlobalVariables.Shared.SuccessMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(_Result, 500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("MyProfile")]
        public Result MyProfile(ArrayList Array)
        {
            SE_MyProfile _Details = new SE_MyProfile();
            SE_MyProfile _Records = new SE_MyProfile();

            try
            {
                foreach (JObject val in Array)
                    _Details = val.ToObject<SE_MyProfile>();

                _Records.FirstName = AES_Algorithm.EncryptString(RSAPattern.Decrypt(_Details.FirstName));
                _Records.LastName = AES_Algorithm.EncryptString(RSAPattern.Decrypt(_Details.LastName));
                _Records.Email = SymmetricAlgorithm.Encrypt(RSAPattern.Decrypt(_Details.Email));

                if (_Details.Gender != null)
                    _Records.Gender = AES_Algorithm.EncryptString(RSAPattern.Decrypt(_Details.Gender));
                if (_Details.PAddress != null)
                    _Records.PAddress = AES_Algorithm.EncryptString(RSAPattern.Decrypt(_Details.PAddress));
                if (_Details.PCity != null)
                    _Records.PCity = AES_Algorithm.EncryptString(RSAPattern.Decrypt(_Details.PCity));
                if (_Details.PStateId != null)
                    _Records.PStateId = RSAPattern.Decrypt(_Details.PStateId);
                if (_Details.PCountryId != null)
                    _Records.PCountryId = RSAPattern.Decrypt(_Details.PCountryId);
                if (_Details.PZipCode != null)
                    _Records.PZipCode = RSAPattern.Decrypt(_Details.PZipCode);
                _Records.isCurrentPermanent = _Details.isCurrentPermanent;
                if (!Convert.ToBoolean(_Details.isCurrentPermanent))
                {
                    if (_Details.CAddress != null)
                        _Records.CAddress = AES_Algorithm.EncryptString(RSAPattern.Decrypt(_Details.CAddress));
                    if (_Details.CCity != null)
                        _Records.CCity = AES_Algorithm.EncryptString(RSAPattern.Decrypt(_Details.CCity));
                    if (_Details.CStateId != null)
                        _Records.CStateId = RSAPattern.Decrypt(_Details.CStateId);
                    if (_Details.CCountryId != null)
                        _Records.CCountryId = RSAPattern.Decrypt(_Details.CCountryId);
                    if (_Details.CZipCode != null)
                        _Records.CZipCode = RSAPattern.Decrypt(_Details.CZipCode);
                }
                _Records.ProfilePic = _Details.ProfilePic;
                if (_Details.ImgType != null)
                    _Records.ImgType = RSAPattern.Decrypt(_Details.ImgType);

                int _Result = _ObjCPanel.InsertUpdateMyProfile(_Records);

                if (_Result == 1)
                    return Result.Success(200, GlobalVariables.Shared.DetailsUpdatedMsg, GlobalVariables.Shared.SuccessMsg);
                else
                    return Result.Failed(500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("GetCountries")]
        public Result<List<SE_RefValues>> GetCountries(ArrayList Array)
        {
            List<SE_RefValues> _lst = new List<SE_RefValues>();
            try
            {
                _lst = _ObjCPanel.GetCountries();
                return Result.Success(_lst, 200, GlobalVariables.Shared.SuccessMsg, GlobalVariables.Shared.SuccessMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(_lst, 500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [HttpPost, Route("GetStates")]
        public Result<List<SE_RefValues>> GetStates(ArrayList Array)
        {
            List<SE_RefValues> _lst = new List<SE_RefValues>();
            try
            {
                _lst = _ObjCPanel.GetStates();
                return Result.Success(_lst, 200, GlobalVariables.Shared.SuccessMsg, GlobalVariables.Shared.SuccessMsg);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(_lst, 500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }

        [Authorize, HttpPost, Route("RolesList")]
        public Result<List<SE_RefValues>> RolesList(ArrayList Array)
        {
            List<SE_RefValues> _lst = new List<SE_RefValues>();
            try
            {
                _lst = _ObjCPanel.RolesList();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Result.Failed(_lst, 500, GlobalVariables.Shared.InternalServerErrorMsg);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Application.Controllers
{
    public class ConfirmationController : Controller
    {
        public ActionResult Registration()
        {
            return View();
        }
        public ActionResult ForgotPwd()
        {
            return View();
        }
    }
}
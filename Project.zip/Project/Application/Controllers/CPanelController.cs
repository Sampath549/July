﻿using Application.App_Start;
using Application.Filters;
using Application.Helper;
using Application.Models.SharedEntities;
using Microsoft.Security.Application;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Device.Location;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Windows.Forms;

namespace Application.Controllers
{
    public class CPanelController : Controller
    {
        #region Design Pages for Login, Registration, ForgotPassword
        // Note: 
        // 1) Content Security Policy for all the Startup pages.
        // 2) Error Redirecting to the Page depending on the status code. And can choose whether to insert in Error log text document or not.    

        [ContentSecurityPolicy]
        public ActionResult Login()
        {
            try
            {
                ViewBag.AllowedBrowser = Reusable.BrowserCheck(Request.Browser.Browser); // Checking Browser
                return View();
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }

        [ContentSecurityPolicy]
        public ActionResult Registration()
        {
            try
            {
                ViewBag.AllowedBrowser = Reusable.BrowserCheck(Request.Browser.Browser); // Checking Browser
                return View();
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }

        [ContentSecurityPolicy]
        public ActionResult ForgotPassword()
        {
            try
            {
                ViewBag.AllowedBrowser = Reusable.BrowserCheck(Request.Browser.Browser); // Checking Browser
                return View();
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }
        #endregion

        #region POST Methods for Login, MultiLogin Validation, Registration, ForgotPassword
        // Note:
        // 1) CSRF AntiForgeryToken for all POST Methods.
        // 2) Error Message depending on the status code. And can choose whether to insert in Error log text document or not.  

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult MultiLogin(string _User, string _Password)
        {
            string MultiLoginSession = string.Empty;
            try
            {
                if (GlobalVariables.Shared.MultiLoginEnable)
                {
                    if (CheckAuthOfMultiLogin(_User, _Password))
                    {
                        //Check-MultiLogin
                        if (System.Web.HttpContext.Current.Session["MultiLogin"] != null)
                            MultiLoginSession = System.Web.HttpContext.Current.Session["MultiLogin"].ToString();
                        else
                            MultiLoginSession = "";

                        //API Call
                        ArrayList _MultiLoginArray = new ArrayList();
                        _MultiLoginArray.Add(RSAPattern.Encrypt(_User));
                        _MultiLoginArray.Add(RSAPattern.Encrypt(MultiLoginSession));
                        _MultiLoginArray.Add(RSAPattern.Encrypt(GlobalVariables.Shared.MultiLoginCheck));

                        string res = ApiHelper.PostData_Json_NToken("api/CPanel/MultiLogin?Values=", _MultiLoginArray);
                        Result<int> _ResultMultiLogin = JsonConvert.DeserializeObject<Result<int>>(res);

                        return Json(new Result<bool>(Convert.ToBoolean(_ResultMultiLogin.Data), true, 200, GlobalVariables.Shared.SuccessMsg, null), JsonRequestBehavior.AllowGet);
                    }
                    else
                        return Json(new Result<bool>(false, true, 200, GlobalVariables.Shared.SuccessMsg, null), JsonRequestBehavior.AllowGet);
                }
                else
                    return Json(new Result<bool>(false, true, 200, GlobalVariables.Shared.SuccessMsg, null), JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Json(new Result<bool>(false, false, 500, GlobalVariables.Shared.InternalServerErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        private bool CheckAuthOfMultiLogin(string Email, string Password)
        {
            //API Call
            ArrayList _Array = new ArrayList();
            _Array.Add(RSAPattern.Encrypt(Email));
            _Array.Add(RSAPattern.Encrypt(Password));

            string response = ApiHelper.PostData_Json_NToken("api/CPanel/LoginAuthentication?Values=", _Array);
            Result<SE_Users> _Result = JsonConvert.DeserializeObject<Result<SE_Users>>(response);

            if (_Result.Data.Status == 1)
                return true;
            else
                return false;
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult LoginAuthentication(string _User, string _Password, string _ReCaptcha)
        {
            SE_Users Users = new SE_Users();
            ArrayList _Array = new ArrayList();
            try
            {
                //Checking ReCaptcha Required or Not
                if (GlobalVariables.Shared.ReCaptcha)
                {
                    bool chk = isCaptchaValid(_ReCaptcha);
                    if (!chk)
                        return Json(new object[] { new object() }, JsonRequestBehavior.AllowGet);
                }

                //Server-Side Validations
                if (_User == null || Sanitizer.GetSafeHtmlFragment(_User) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User), @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)+$") == false)
                    return Json(new object[] { new object() }, JsonRequestBehavior.AllowGet);
                if (_Password == null || Sanitizer.GetSafeHtmlFragment(_Password) == "")
                    return Json(new object[] { new object() }, JsonRequestBehavior.AllowGet);

                //RSA Encryption
                Users = new SE_Users();
                Users.Email = RSAPattern.Encrypt(_User);
                Users.Password = RSAPattern.Encrypt(_Password);
                Users.IPAddress = Request.UserHostAddress;
                Users.EntryType = "";
                Users.EntryFrom = GlobalVariables.Shared.EntryFrom;
                Users.BrowserName = Request.Browser.Browser;
                Users.BrowserVersion = Request.Browser.Version;
                Users.ResolutionWidth = Screen.PrimaryScreen.Bounds.Width.ToString();
                Users.ResolutionHeight = Screen.PrimaryScreen.Bounds.Height.ToString();
                string[] LatLon = GetLatLon().Split('^'); // GEO Location
                Users.Latitude = LatLon[0];
                Users.Longitude = LatLon[1];
                Users.Location = LatLon[2];

                //Audit
                ArrayList _Audit = new ArrayList();
                _Audit.Add(Users);
                string responseAudit = ApiHelper.PostData_Json_NToken("api/CPanel/Audit?Values=", _Audit);

                //API Call
                _Array = new ArrayList();
                _Array.Add(Users.Email);
                _Array.Add(Users.Password);

                string response = ApiHelper.PostData_Json_NToken("api/CPanel/LoginAuthentication?Values=", _Array);
                Result<SE_Users> _Result = JsonConvert.DeserializeObject<Result<SE_Users>>(response);

                if (_Result.Data.Status == 1)
                {
                    if (_Result.Data.TimeDiff > 4 || _Result.Data.DisableAccountTime == null)
                    {
                        if (GlobalVariables.Shared.MultiLoginEnable)
                        {
                            //Insert-MultiLogin
                            string MultiLoginSession = Guid.NewGuid().ToString();
                            System.Web.HttpContext.Current.Session["MultiLogin"] = MultiLoginSession;

                            //API Call
                            ArrayList _MultiLoginInsertArray = new ArrayList();
                            _MultiLoginInsertArray.Add(RSAPattern.Encrypt(_User));
                            _MultiLoginInsertArray.Add(RSAPattern.Encrypt(MultiLoginSession));
                            _MultiLoginInsertArray.Add(RSAPattern.Encrypt(GlobalVariables.Shared.MultiLoginInsert));

                            string resInsert = ApiHelper.PostData_Json_NToken("api/CPanel/MultiLogin?Values=", _MultiLoginInsertArray);
                            Result<int> _ResultMultiLoginInsert = JsonConvert.DeserializeObject<Result<int>>(resInsert);
                        }

                        //Access Token
                        SessionHandler.AuthName = _User;
                        SessionHandler.AuthPwd = _Password;

                        _Result.Data.FirstName = RSAPattern.Decrypt(_Result.Data.FirstName);
                        _Result.Data.LastName = RSAPattern.Decrypt(_Result.Data.LastName);
                        _Result.Data.Email = RSAPattern.Decrypt(_Result.Data.Email);
                        _Result.Data.Mobile = RSAPattern.Decrypt(_Result.Data.Mobile);

                        string FullName = _Result.Data.FirstName + " " + _Result.Data.LastName;
                        SessionHandler.WelcomeNameTitle = FullName;
                        if (FullName.Length > 25)
                            FullName = FullName.Substring(0, 25) + "...";
                        SessionHandler.WelcomeName = FullName;

                        if (_Result.Data.ProfilePic != null)
                            SessionHandler.ProfilePic = _Result.Data.ProfilePic;

                        SessionHandler.UserDetails = _Result.Data;
                        return Json(new Result<SE_Users>(_Result.Data, _Result.Status, _Result.StatusCode, _Result.Caption, _Result.Message), JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        _Result.Data.Status = 0;
                        return Json(new Result<SE_Users>(_Result.Data, _Result.Status, _Result.StatusCode, GlobalVariables.Shared.AccoundDisabledErrorMsg, GlobalVariables.Shared.AccoundDisabledValidationMsg), JsonRequestBehavior.AllowGet);
                    }
                }
                else
                    return Json(new Result<SE_Users>(_Result.Data, _Result.Status, _Result.StatusCode, _Result.Caption, _Result.Message), JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Json(new Result<SE_Users>(Users, false, 500, GlobalVariables.Shared.InternalServerErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult Registration(SE_Users _User)
        {
            SE_Users Users = new SE_Users();
            try
            {
                //Server-Side Validations
                if (_User.FirstName == null || Sanitizer.GetSafeHtmlFragment(_User.FirstName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.FirstName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_User.FirstName).Length > 35 || Sanitizer.GetSafeHtmlFragment(_User.FirstName).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "First Name should not be Empty and must contain only Alphabets with Minimum of 3 characters"), JsonRequestBehavior.AllowGet);
                if (_User.LastName == null || Sanitizer.GetSafeHtmlFragment(_User.LastName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.LastName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_User.LastName).Length > 35 || Sanitizer.GetSafeHtmlFragment(_User.LastName).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Last Name should not be Empty and must contain only Alphabets with Minimum of 3 characters"), JsonRequestBehavior.AllowGet);
                if (_User.Email == null || Sanitizer.GetSafeHtmlFragment(_User.Email) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.Email), @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)+$") == false || Sanitizer.GetSafeHtmlFragment(_User.Email).Length > 75)
                    return Json(new Result(false, 500, "Validation Error", "Email should not be Empty and must be a Valid format with max of 75 characters"), JsonRequestBehavior.AllowGet);
                if (_User.Mobile == null || Sanitizer.GetSafeHtmlFragment(_User.Mobile) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.Mobile), @"^[0-9]+$") == false || Sanitizer.GetSafeHtmlFragment(_User.Mobile).Length != 10)
                    return Json(new Result(false, 500, "Validation Error", "Mobile should not be Empty and must contain only Numbers with 10 digits"), JsonRequestBehavior.AllowGet);

                //RSA Encryption
                Users = new SE_Users();
                Users.FirstName = RSAPattern.Encrypt(_User.FirstName);
                Users.LastName = RSAPattern.Encrypt(_User.LastName);
                Users.Email = RSAPattern.Encrypt(_User.Email);
                Users.Mobile = RSAPattern.Encrypt(_User.Mobile);

                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(Users);
                string response = ApiHelper.PostData_Json_NToken("api/CPanel/Registration?Users=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Json(new Result<SE_Users>(Users, false, 500, GlobalVariables.Shared.InternalServerErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult ForgotPassword(string _Email)
        {
            SE_Users Users = new SE_Users();
            try
            {
                //Server-Side Validations
                if (_Email == null || Sanitizer.GetSafeHtmlFragment(_Email) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_Email), @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)+$") == false || Sanitizer.GetSafeHtmlFragment(_Email).Length > 75)
                    return Json(new Result(false, 500, "Validation Error", "Email should not be Empty and must be a Valid format with max of 75 characters"), JsonRequestBehavior.AllowGet);

                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(_Email));
                string response = ApiHelper.PostData_Json_NToken("api/CPanel/ForgotPasswordLink?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Json(new Result<SE_Users>(Users, false, 500, GlobalVariables.Shared.InternalServerErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region Reset Password (View & POST)
        public ActionResult ResetPassword(string Value)
        {
            if (Sanitizer.GetSafeHtmlFragment(Value) != "" || Value != null)
            {
                DateTime CurrentDate = DateTime.Now;
                try
                {
                    var response = ApiHelper.GetDataParam_String_NToken("api/CPanel/GetLinkExpiryTime?StringVal=", Value);
                    string resultAdd = JsonConvert.DeserializeObject(response).ToString();
                    string[] _List = resultAdd.Split('^');

                    if (!Convert.ToBoolean(_List[1]))
                    {
                        int TotalTime = Convert.ToInt32(CurrentDate.Subtract(Convert.ToDateTime(_List[0])).TotalMinutes);
                        int ExpiryTime = GlobalVariables.Shared.EmailLinkExpiry;
                        if (TotalTime > ExpiryTime)
                            ViewBag.TimeExpired = true;
                        else
                            ViewBag.TimeExpired = false;
                        ViewBag.LinkClicked = false;
                    }
                    else
                        ViewBag.LinkClicked = true;
                }
                catch (Exception ex)
                {
                    return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
                }
            }
            return View();
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult ResetPassword(string Email, string Password, string CPassword, string GuidVal)
        {
            var score = 0;
            try
            {
                //Server-Side Validations
                if (Email == null || Sanitizer.GetSafeHtmlFragment(Email) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Email), @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)+$") == false || Sanitizer.GetSafeHtmlFragment(Email).Length > 75)
                    return Json(new Result(false, 500, "Validation Error", "Email should not be Empty and must be a Valid format"), JsonRequestBehavior.AllowGet);

                if (Password.Length >= 8 && Password.Length < 50)
                {
                    score = 0;

                    if (Regex.Match(Password, @"\d", RegexOptions.ECMAScript).Success)
                        score++;
                    if (Regex.Match(Password, @"[a-z]", RegexOptions.ECMAScript).Success)
                        score++;
                    if (Regex.Match(Password, @"[A-Z]", RegexOptions.ECMAScript).Success)
                        score++;
                    if (Regex.Match(Password, @"[!,@,#,$,%,^,&,*,?,_,~,-,£,(,),\s]", RegexOptions.ECMAScript).Success)
                        score++;
                    if (score < 4)
                        return Json(new Result(false, 500, "Validation Error", "Password should contain minmum 1 Upper character, 1 Lower character, 1 Number and 1 Special character."), JsonRequestBehavior.AllowGet);
                }
                else
                    return Json(new Result(false, 500, "Validation Error", "Password should contain Min 8 & Max 50 Characters"), JsonRequestBehavior.AllowGet);

                if (Password != CPassword)
                    return Json(new Result(false, 500, "Validation Error", "Password and Confirm Password should be same"), JsonRequestBehavior.AllowGet);
                if (GuidVal == null || Sanitizer.GetSafeHtmlFragment(GuidVal) == "")
                    return Json(new Result(false, 500, "Validation Error", "Parameter value should not be Empty"), JsonRequestBehavior.AllowGet);

                //RSA Encryption
                List<string> _Val = new List<string>();
                _Val.Add(RSAPattern.Encrypt(Email));
                _Val.Add(RSAPattern.Encrypt(Password));
                _Val.Add(GuidVal.Replace(" ", "+"));

                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(_Val);
                string response = ApiHelper.PostData_Json_NToken("api/CPanel/ResetPassword?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Json(new Result<bool>(false, false, 500, GlobalVariables.Shared.InternalServerErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region One Time Password
        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult OneTimePassword(string OldPassword, string Password, string CPassword)
        {
            var score = 0;
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            try
            {
                //Server-Side Validations		
                if (OldPassword == null || Sanitizer.GetSafeHtmlFragment(OldPassword) == "" || Sanitizer.GetSafeHtmlFragment(OldPassword).Length < 8 || Sanitizer.GetSafeHtmlFragment(OldPassword).Length > 50)
                    return Json(new Result(false, 500, "Validation Error", "Old Password should contain Min 8 & Max 50 Characters"), JsonRequestBehavior.AllowGet);

                if (Password.Length >= 8 && Password.Length < 50)
                {
                    score = 0;

                    if (Regex.Match(Password, @"\d", RegexOptions.ECMAScript).Success)
                        score++;
                    if (Regex.Match(Password, @"[a-z]", RegexOptions.ECMAScript).Success)
                        score++;
                    if (Regex.Match(Password, @"[A-Z]", RegexOptions.ECMAScript).Success)
                        score++;
                    if (Regex.Match(Password, @"[!,@,#,$,%,^,&,*,?,_,~,-,£,(,),\s]", RegexOptions.ECMAScript).Success)
                        score++;
                    if (score < 4)
                        return Json(new Result(false, 500, "Validation Error", "New Password should contain minmum 1 Upper character, 1 Lower character, 1 Number and 1 Special character."), JsonRequestBehavior.AllowGet);
                }
                else
                    return Json(new Result(false, 500, "Validation Error", "Password should contain Min 8 & Max 50 Characters"), JsonRequestBehavior.AllowGet);

                if (Password != CPassword)
                    return Json(new Result(false, 500, "Validation Error", "Password and Confirm Password should be same"), JsonRequestBehavior.AllowGet);

                //RSA Encryption		
                List<string> _Val = new List<string>();
                _Val.Add(RSAPattern.Encrypt(OldPassword));
                _Val.Add(RSAPattern.Encrypt(Password));
                _Val.Add(RSAPattern.Encrypt(_SessionUserDetails.UserId.ToString()));

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Val);
                string response = ApiHelper.PostData_Json("api/CPanel/OneTimePassword?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                if (_Result.Status == true)
                {
                    SessionHandler.AuthPwd = Password;
                    _SessionUserDetails.IsFirstTimeLogin = false;
                    SessionHandler.UserDetails = _SessionUserDetails;
                }

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Json(new Result(false, 500, GlobalVariables.Shared.InternalServerErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region User Details (My Profile, Change Password)
        public ActionResult MyProfile()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            try
            {
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
                ViewBag.Gender_ddl = Reusable.GenderList();
                ViewBag.PCountries = Reusable.CountriesList();
                ViewBag.CCountries = Reusable.CountriesList();
                ViewBag.PStates = Reusable.StatesList();
                ViewBag.CStates = Reusable.StatesList();

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(RSAPattern.Encrypt(_SessionUserDetails.Email));
                string response = ApiHelper.PostData_Json("api/CPanel/MyProfileDetails?Values=", _Array);
                Result<SE_MyProfile> _Result = JsonConvert.DeserializeObject<Result<SE_MyProfile>>(response);

                SE_MyProfile _UserMapping = new SE_MyProfile();
                _UserMapping.FirstName = _SessionUserDetails.FirstName;
                _UserMapping.LastName = _SessionUserDetails.LastName;
                _UserMapping.Email = _SessionUserDetails.Email;
                _UserMapping.Mobile = _SessionUserDetails.Mobile;
                _UserMapping.RoleCode = _SessionUserDetails.RoleCode;
                if (_Result.Data.Gender != null)
                    _UserMapping.Gender = RSAPattern.Decrypt(_Result.Data.Gender);
                if (_Result.Data.ProfilePic != null)
                    _UserMapping.ProfilePic = _Result.Data.ProfilePic;
                if (_Result.Data.ImgType != null)
                    _UserMapping.ImgType = _Result.Data.ImgType;
                if (_Result.Data.isCurrentPermanent != null)
                    _UserMapping.isCurrentPermanent = _Result.Data.isCurrentPermanent;
                if (_Result.Data.PAddress != null)
                    _UserMapping.PAddress = RSAPattern.Decrypt(_Result.Data.PAddress);
                if (_Result.Data.PCity != null)
                    _UserMapping.PCity = RSAPattern.Decrypt(_Result.Data.PCity);
                if (_Result.Data.PStateId != null)
                    _UserMapping.PStateId = _Result.Data.PStateId;
                if (_Result.Data.PCountryId != null)
                    _UserMapping.PCountryId = _Result.Data.PCountryId;
                if (_Result.Data.PZipCode != null)
                    _UserMapping.PZipCode = RSAPattern.Decrypt(_Result.Data.PZipCode);
                if (_Result.Data.CAddress != null)
                    _UserMapping.CAddress = RSAPattern.Decrypt(_Result.Data.CAddress);
                if (_Result.Data.CCity != null)
                    _UserMapping.CCity = RSAPattern.Decrypt(_Result.Data.CCity);
                if (_Result.Data.CStateId != null)
                    _UserMapping.CStateId = _Result.Data.CStateId;
                if (_Result.Data.CCountryId != null)
                    _UserMapping.CCountryId = _Result.Data.CCountryId;
                if (_Result.Data.CZipCode != null)
                    _UserMapping.CZipCode = RSAPattern.Decrypt(_Result.Data.CZipCode);
                _UserMapping.ProfilePic = _Result.Data.ProfilePic;
                if (_Result.Data.ImgType != null)
                    _UserMapping.ImgType = _Result.Data.ImgType;

                return View(_UserMapping);
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken, MVCSessionFilter]
        public JsonResult MyProfile(SE_MyProfile UserDetails)
        {
            SE_MyProfile _Usr = new SE_MyProfile();
            List<string> _Data = new List<string>();
            try
            {
                //Server-Side Validations
                if (UserDetails.FirstName == null || Sanitizer.GetSafeHtmlFragment(UserDetails.FirstName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(UserDetails.FirstName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(UserDetails.FirstName).Length > 35)
                    return Json(new Result(false, 500, "Validation Error", "FirstName should not be Empty and must contain only Alphabets with not more than of 35 characters"), JsonRequestBehavior.AllowGet);
                if (UserDetails.LastName == null || Sanitizer.GetSafeHtmlFragment(UserDetails.LastName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(UserDetails.LastName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(UserDetails.LastName).Length > 35)
                    return Json(new Result(false, 500, "Validation Error", "LastName should not be Empty and must contain only Alphabets with not more than of 35 characters"), JsonRequestBehavior.AllowGet);

                if (UserDetails.ProfilePic != null)
                {
                    List<string> _ext = Reusable.ProfilePicExtentions();
                    if (!_ext.Contains(UserDetails.ImgType))
                        return Json(new Result(false, 500, "Validation Error", "Upload Images of Extentions .JPG, .JPEG, .PNG"), JsonRequestBehavior.AllowGet);
                }

                SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;

                //RSA Encryption	   
                _Usr.UserId = _SessionUserDetails.UserId;
                _Usr.FirstName = RSAPattern.Encrypt(UserDetails.FirstName);
                _Usr.LastName = RSAPattern.Encrypt(UserDetails.LastName);
                _Usr.Email = RSAPattern.Encrypt(_SessionUserDetails.Email);
                if (UserDetails.Gender != "0")
                    _Usr.Gender = RSAPattern.Encrypt(UserDetails.Gender);
                if (UserDetails.PAddress != null)
                    _Usr.PAddress = RSAPattern.Encrypt(UserDetails.PAddress);
                if (UserDetails.PCity != null)
                    _Usr.PCity = RSAPattern.Encrypt(UserDetails.PCity);
                if (UserDetails.PStateId != "0")
                    _Usr.PStateId = RSAPattern.Encrypt(UserDetails.PStateId);
                if (UserDetails.PCountryId != "0")
                    _Usr.PCountryId = RSAPattern.Encrypt(UserDetails.PCountryId);
                if (UserDetails.PZipCode != null)
                    _Usr.PZipCode = RSAPattern.Encrypt(UserDetails.PZipCode);
                _Usr.isCurrentPermanent = UserDetails.isCurrentPermanent;
                if (!Convert.ToBoolean(UserDetails.isCurrentPermanent))
                {
                    if (UserDetails.CAddress != null)
                        _Usr.CAddress = RSAPattern.Encrypt(UserDetails.CAddress);
                    if (UserDetails.CCity != null)
                        _Usr.CCity = RSAPattern.Encrypt(UserDetails.CCity);
                    if (UserDetails.CStateId != "0")
                        _Usr.CStateId = RSAPattern.Encrypt(UserDetails.CStateId);
                    if (UserDetails.CCountryId != "0")
                        _Usr.CCountryId = RSAPattern.Encrypt(UserDetails.CCountryId);
                    if (UserDetails.CZipCode != null)
                        _Usr.CZipCode = RSAPattern.Encrypt(UserDetails.CZipCode);
                }
                _Usr.ProfilePic = UserDetails.ProfilePic;
                if (UserDetails.ImgType != null)
                    _Usr.ImgType = RSAPattern.Encrypt(UserDetails.ImgType);

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Usr);
                string response = ApiHelper.PostData_Json("api/CPanel/MyProfile?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                if (_Result.Status)
                {
                    string FullName = UserDetails.FirstName + " " + UserDetails.LastName;
                    SessionHandler.WelcomeNameTitle = FullName;
                    if (FullName.Length > 25)
                        FullName = FullName.Substring(0, 25) + "...";
                    SessionHandler.WelcomeName = FullName;

                    if (UserDetails.ProfilePic != null)
                        SessionHandler.ProfilePic = UserDetails.ProfilePic;

                    _SessionUserDetails.FirstName = UserDetails.FirstName;
                    _SessionUserDetails.LastName = UserDetails.LastName;
                    SessionHandler.UserDetails = _SessionUserDetails;

                    _Data = new List<string>(new string[] { _Result.Status.ToString(), _Result.Message, _Result.Caption, Reusable.RedirectPage(_SessionUserDetails.RoleCode) });
                }
                return Json(_Data, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ExceptionHandling.ErrorPage(ex, 500);
                return Json(new { _Data = new List<string>(new string[] { "False", GlobalVariables.Shared.InternalServerErrorMsg, null, null }) }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult ChangePassword()
        {
            try
            {
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
                return View();
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }
        #endregion

        #region Private Functions
        private bool isCaptchaValid(string res)
        {
            var result = false;
            var captchaResponse = res;
            var secretKey = "6Le8IokUAAAAAJnKCaDOrbkMKVHaw9v1Cgq8GchF";
            var apiUrl = "https://www.google.com/recaptcha/api/siteverify?secret={0}&response={1}";
            var requestUri = string.Format(apiUrl, secretKey, captchaResponse);
            var request = (HttpWebRequest)WebRequest.Create(requestUri);

            using (WebResponse response = request.GetResponse())
            {
                using (StreamReader stream = new StreamReader(response.GetResponseStream()))
                {
                    JObject jResponse = JObject.Parse(stream.ReadToEnd());
                    var isSuccess = jResponse.Value<bool>("success");
                    result = (isSuccess) ? true : false;
                }
            }
            return result;
        }
        private string GetLatLon()
        {
            string Latitude = string.Empty;
            string Longitude = string.Empty;
            string Location = string.Empty;

            GeoCoordinateWatcher watcher = new GeoCoordinateWatcher();
            watcher.TryStart(false, TimeSpan.FromMilliseconds(5000));
            GeoCoordinate coord = watcher.Position.Location;
            if (!watcher.Position.Location.IsUnknown)
            {
                Latitude = watcher.Position.Location.Latitude.ToString();
                Longitude = watcher.Position.Location.Longitude.ToString();
                ////Sam Change Code
                //IGeocoder geocoder = new GoogleGeocoder(GlobalVariables.Shared.IPLocationAPIKey);
                //IEnumerable<Address> addresses = geocoder.ReverseGeocode(Convert.ToDouble(Users.Latitude), Convert.ToDouble(Users.Longitude));
                //Users.Location = ((Geocoding.Google.GoogleAddress[])(addresses))[0].FormattedAddress; 
                Location = "";
            }
            else
            {
                GetLatLon();
            }
            watcher.Stop();
            return Latitude + "^" + Longitude + "^" + Location;
        }
        #endregion

        #region Manual Logout
        [HttpGet]
        public ActionResult Logout()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;

            //API Call
            ArrayList _MultiLoginArray = new ArrayList();
            _MultiLoginArray.Add(RSAPattern.Encrypt(_SessionUserDetails.Email));

            string res = ApiHelper.PostData_Json("api/CPanel/LogoutMultiLogin?Values=", _MultiLoginArray);
            Result<int> _ResultMultiLogin = JsonConvert.DeserializeObject<Result<int>>(res);

            FormsAuthentication.SignOut();
            System.Web.HttpContext.Current.Session.Clear();
            System.Web.HttpContext.Current.Session.RemoveAll();
            System.Web.HttpContext.Current.Session.Abandon();

            HttpCookie cookie1 = new HttpCookie(FormsAuthentication.FormsCookieName, "");
            cookie1.Expires = DateTime.Now.AddYears(-1);
            cookie1.Secure = true;
            cookie1.HttpOnly = true;
            cookie1.Path += ";SameSite=Strict";
            System.Web.HttpContext.Current.Response.Cookies.Add(cookie1);

            HttpCookie cookie2 = new HttpCookie("s", "");
            cookie2.Expires = DateTime.Now.AddYears(-1);
            cookie2.Secure = true;
            cookie2.HttpOnly = true;
            cookie2.Path += ";SameSite=Strict";
            System.Web.HttpContext.Current.Response.Cookies.Add(cookie2);

            Response.Cookies.Add(new HttpCookie("ASP.NET_SessionId", ""));
            if (Request.Cookies["ASP.NET_SessionId"] != null)
            {
                Response.Cookies["ASP.NET_SessionId"].Value = string.Empty;
                Response.Cookies["ASP.NET_SessionId"].Expires = DateTime.Now.AddMonths(-20);
            }

            Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
            Response.Cache.SetNoStore();

            SessionHandler.UserDetails = null;
            SessionHandler.AuthName = null;
            SessionHandler.AuthPwd = null;
            SessionHandler.WelcomeNameTitle = null;
            SessionHandler.WelcomeName = null;
            SessionHandler.ProfilePic = null;
            SessionHandler.Menus = null;

            return RedirectToAction("Login", "CPanel");
        }
        #endregion

        #region Session Logout
        [HttpGet]
        public ActionResult SessionLogout()
        {
            bool result = false;
            try
            {
                SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;

                //API Call
                ArrayList _MultiLoginArray = new ArrayList();
                _MultiLoginArray.Add(RSAPattern.Encrypt(_SessionUserDetails.Email));

                string res = ApiHelper.PostData_Json("api/CPanel/LogoutMultiLogin?Values=", _MultiLoginArray);
                Result<int> _ResultMultiLogin = JsonConvert.DeserializeObject<Result<int>>(res);

                FormsAuthentication.SignOut();

                System.Web.HttpContext.Current.Session.Clear();
                System.Web.HttpContext.Current.Session.RemoveAll();
                System.Web.HttpContext.Current.Session.Abandon();

                HttpCookie cookie1 = new HttpCookie(FormsAuthentication.FormsCookieName, "");
                cookie1.Expires = DateTime.Now.AddYears(-1);
                cookie1.Secure = true;
                cookie1.HttpOnly = true;
                cookie1.Path += ";SameSite=Strict";
                System.Web.HttpContext.Current.Response.Cookies.Add(cookie1);

                HttpCookie cookie2 = new HttpCookie("s", "");
                cookie2.Expires = DateTime.Now.AddYears(-1);
                cookie2.Secure = true;
                cookie2.HttpOnly = true;
                cookie2.Path += ";SameSite=Strict";
                System.Web.HttpContext.Current.Response.Cookies.Add(cookie2);

                Response.Cookies.Add(new HttpCookie("ASP.NET_SessionId", ""));
                if (Request.Cookies["ASP.NET_SessionId"] != null)
                {
                    Response.Cookies["ASP.NET_SessionId"].Value = string.Empty;
                    Response.Cookies["ASP.NET_SessionId"].Expires = DateTime.Now.AddMonths(-20);
                }

                Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
                Response.Cache.SetNoStore();

                SessionHandler.UserDetails = null;
                SessionHandler.AuthName = null;
                SessionHandler.AuthPwd = null;
                SessionHandler.WelcomeNameTitle = null;
                SessionHandler.WelcomeName = null;
                SessionHandler.ProfilePic = null;
                SessionHandler.Menus = null;

                result = true;
            }
            catch
            {
                result = false;
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult SessionLogoutIfNull(string UID)
        {
            try
            {
                //API Call
                ArrayList _MultiLoginArray = new ArrayList();
                _MultiLoginArray.Add(RSAPattern.Encrypt(UID));

                string res = ApiHelper.PostData_Json_NToken("api/CPanel/LogoutMultiLoginIfNull?Values=", _MultiLoginArray);
                Result<int> _ResultMultiLogin = JsonConvert.DeserializeObject<Result<int>>(res);

                FormsAuthentication.SignOut();

                System.Web.HttpContext.Current.Session.Clear();
                System.Web.HttpContext.Current.Session.RemoveAll();
                System.Web.HttpContext.Current.Session.Abandon();

                HttpCookie cookie1 = new HttpCookie(FormsAuthentication.FormsCookieName, "");
                cookie1.Expires = DateTime.Now.AddYears(-1);
                cookie1.Secure = true;
                cookie1.HttpOnly = true;
                cookie1.Path += ";SameSite=Strict";
                System.Web.HttpContext.Current.Response.Cookies.Add(cookie1);

                HttpCookie cookie2 = new HttpCookie("s", "");
                cookie2.Expires = DateTime.Now.AddYears(-1);
                cookie2.Secure = true;
                cookie2.HttpOnly = true;
                cookie2.Path += ";SameSite=Strict";
                System.Web.HttpContext.Current.Response.Cookies.Add(cookie2);

                Response.Cookies.Add(new HttpCookie("ASP.NET_SessionId", ""));
                if (Request.Cookies["ASP.NET_SessionId"] != null)
                {
                    Response.Cookies["ASP.NET_SessionId"].Value = string.Empty;
                    Response.Cookies["ASP.NET_SessionId"].Expires = DateTime.Now.AddMonths(-20);
                }

                Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
                Response.Cache.SetNoStore();

                SessionHandler.UserDetails = null;
                SessionHandler.AuthName = null;
                SessionHandler.AuthPwd = null;
                SessionHandler.WelcomeNameTitle = null;
                SessionHandler.WelcomeName = null;
                SessionHandler.ProfilePic = null;
                SessionHandler.Menus = null;

                return RedirectToAction("SessionExpired", "Error");
            }
            catch (Exception ex)
            {
                return RedirectToAction(ExceptionHandling.ErrorPage(ex, 500), "Error");
            }
        }
        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Web;

namespace Application.Helper
{
    public static class RSAPattern
    {
        public static string Encrypt(string Value)
        {
            return RSAMessageEncryption(Value);
        }
        public static string Decrypt(string Value)
        {
            return RSAMessageDecrypt(Value);
        }
        private static string RSAMessageEncryption(string strChipertext)
        {
            var csp = new RSACryptoServiceProvider(2048);
            csp = new RSACryptoServiceProvider();
            csp.FromXmlString(GlobalVariables.Shared.PublicKey);
            var bytesPlainTextData = System.Text.Encoding.Unicode.GetBytes(strChipertext);
            var bytesCypherText = csp.Encrypt(bytesPlainTextData, false);
            var cypherText = Convert.ToBase64String(bytesCypherText);
            return cypherText;
        }
        private static string RSAMessageDecrypt(string strEncryption)
        {
            string decryptedString = string.Empty;
            var csp = new RSACryptoServiceProvider(2048);
            csp = new RSACryptoServiceProvider();
            csp.FromXmlString(GlobalVariables.Shared.PrivateKey);
            string data2Decrypt = strEncryption;
            data2Decrypt = data2Decrypt.Replace(" ", "+");
            byte[] encyrptedBytes = Convert.FromBase64String(data2Decrypt);
            byte[] plain = csp.Decrypt(encyrptedBytes, false);
            decryptedString = System.Text.Encoding.UTF8.GetString(plain);
            if (decryptedString.Contains("\0"))
            {
                decryptedString = decryptedString.Replace("\0", "");
            }
            return decryptedString;
        }
    }
}
﻿using Application.Models.SharedEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Application.Helper
{
    public static class SessionHandler
    {
        public static string AuthName
        {
            get
            {
                return HttpContext.Current.Session["AuthName"] != null ? HttpContext.Current.Session["AuthName"].ToString() : "";
            }
            set
            {
                HttpContext.Current.Session["AuthName"] = value;
            }
        }

        public static string AuthPwd
        {
            get
            {
                return HttpContext.Current.Session["AuthPwd"] != null ? HttpContext.Current.Session["AuthPwd"].ToString() : "";
            }
            set
            {
                HttpContext.Current.Session["AuthPwd"] = value;
            }
        }

        public static SE_Users UserDetails
        {
            get
            {
                return HttpContext.Current.Session["UserDetails"] != null ? HttpContext.Current.Session["UserDetails"] as SE_Users : null;
            }
            set
            {
                HttpContext.Current.Session["UserDetails"] = value;
            }
        }
        public static string Menus
        {
            get
            {
                return HttpContext.Current.Session["_Menus"] != null ? HttpContext.Current.Session["_Menus"].ToString() : "";
            }
            set
            {
                HttpContext.Current.Session["_Menus"] = value;
            }
        }
        public static string WelcomeName
        {
            get
            {
                return HttpContext.Current.Session["WelcomeName"] != null ? HttpContext.Current.Session["WelcomeName"].ToString() : "";
            }
            set
            {
                HttpContext.Current.Session["WelcomeName"] = value;
            }
        }
        public static string WelcomeNameTitle
        {
            get
            {
                return HttpContext.Current.Session["WelcomeNameTitle"] != null ? HttpContext.Current.Session["WelcomeNameTitle"].ToString() : "";
            }
            set
            {
                HttpContext.Current.Session["WelcomeNameTitle"] = value;
            }
        }
        public static string ProfilePic
        {
            get
            {
                return HttpContext.Current.Session["ProfilePic"] != null ? HttpContext.Current.Session["ProfilePic"].ToString() : "";
            }
            set
            {
                HttpContext.Current.Session["ProfilePic"] = value;
            }
        }
        public static List<SelectListItem> Countries
        {
            get
            {
                return HttpContext.Current.Session["_Countries"] != null ? HttpContext.Current.Session["_Countries"] as List<SelectListItem> : null;
            }
            set
            {
                HttpContext.Current.Session["_Countries"] = value;
            }
        }

        public static List<SelectListItem> States
        {
            get
            {
                return HttpContext.Current.Session["_States"] != null ? HttpContext.Current.Session["_States"] as List<SelectListItem> : null;
            }
            set
            {
                HttpContext.Current.Session["_States"] = value;
            }
        }
        public static List<SelectListItem> Roles
        {
            get
            {
                return HttpContext.Current.Session["_Roles"] != null ? HttpContext.Current.Session["_Roles"] as List<SelectListItem> : null;
            }
            set
            {
                HttpContext.Current.Session["_Roles"] = value;
            }
        }
    }
}
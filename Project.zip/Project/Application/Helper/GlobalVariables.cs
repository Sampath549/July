﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;

namespace Application.Helper
{
    public sealed class GlobalVariables
    {
        private static readonly GlobalVariables shared = new GlobalVariables();

        public readonly string OAuthClientId;
        public readonly string OAuthClientSecret;
        public readonly string OAuthTokenExpireSeconds;
        public readonly string PrivateKey;
        public readonly string PublicKey;
        public readonly string AESKey;

        public string Host;
        public int Port;
        public string SenderEmail;
        public string EmailUser;
        public string EmailPwd;
        public bool DontSendMail;
        public bool SendActualMails;
        public string SendDefaultEmailTo;
        public bool SavePasswords;
        public int EmailLinkExpiry;
        public int ForgotPwdClickAgain;

        public readonly string ConfigUrl;
        public readonly string ResetPwdURL;

        public readonly bool InsertErrorLog;
        public readonly bool ReCaptcha;
        public readonly bool MultiLoginEnable;
        public readonly string AllowedBrowsers;

        public readonly string SessionExpired;
        public readonly string InternalServerError;
        public readonly string Unauthorized;
        public readonly string MultiLogin;

        public readonly string EntryFrom;
        public readonly string InternalServerErrorMsg;
        public readonly string InvalidUserPasswordMsg;
        public readonly string ValidationErrorMsg;
        public readonly string SuccessMsg;
        public readonly string AccoundDisabledErrorMsg;
        public readonly string AccoundDisabledValidationMsg;
        public readonly string ChangePwdSuccessMsg;
        public readonly string IncorrectOldPwdMsg;
        public readonly string DetailsUpdatedMsg;
        public readonly string RegistrationSuccessMsg;
        public readonly string DuplicateMailMobileMsg;
        public readonly string RegistrationSuccessMailErrorMsg;
        public readonly string DuplicateRecMsg;
        public readonly string EmailFailedMsg;
        public readonly string ValidationMsg;
        public readonly string RecSaveSuccessMsg;
        public readonly string RecUpdateSuccessMsg;
        public readonly string RecDeleteSuccessMsg;
        public readonly string RecNoExistMsg;

        public readonly string DeveloperRole;
        public readonly string SAdminRole;
        public readonly string AdminRole;
        public readonly string UserRole;
        public readonly string BusinessRole;
        public readonly string CommunityRole;

        public readonly string DeveloperRedirectPage;
        public readonly string SAdminRedirectPage;
        public readonly string AdminRedirectPage;
        public readonly string UserRedirectPage;
        public readonly string BusinessRedirectPage;
        public readonly string CommunityRedirectPage;

        public readonly string MultiLoginCheck;
        public readonly string MultiLoginInsert;

        static GlobalVariables()
        {
        }

        private GlobalVariables()
        {
            OAuthClientId = WebConfigurationManager.AppSettings["OAuthClientId"];
            OAuthClientSecret = WebConfigurationManager.AppSettings["OAuthClientSecret"];
            OAuthTokenExpireSeconds = WebConfigurationManager.AppSettings["OAuthTokenExpireSeconds"];
            PrivateKey = "<RSAKeyValue><Modulus>3SqgT67YOa+InXXxYLQgdcFxAtV3G6oHp9hUfyLciRtPHb0NcFsQ5ZjIB2VYFXc2NUIlysRo2hbmbWJMgU3gV/vL/ItQIb88owYFZx7Cd4qdQGTAw6xMh8RSl+mSHwMtMiJ8F3cZSEs9feXFLad0Yi7DonVl0NXoJU+I3eptEU0=</Modulus><Exponent>AQAB</Exponent><P>34LLnR5XdARSo0gf4JIhWBefsMnWLTwhgJZe+DfCrzqlAAm6ScDmx0bPL5RkH9+l28ngX0G1z5Cwwkoms6kyJw==</P><Q>/VCXbYcdvvJAjySZ9M6iFS4DasXy01X7AarySCBA+qw0vP0cQPqVhkbRlL+nufsvYkSgT4eZSphLKBE27eHtaw==</Q><DP>cPDKqo4Was10ZIWhdfzhVH47dz3GN/1WgH97Zbnnalwb3DUOKQ6Mjs29C7HUFjcQvEr6UagGkufuKX8Gp2orqQ==</DP><DQ>77x+E6J0fGo4v0AclJuaugC6Kyr8DRaqX4GxmqEr3hFsOBAz1StSp6oOX4Ci9FjNF2trbNkgMoC/YEQqgCf50Q==</DQ><InverseQ>vsHoBiTPU7B7TgwpbczYmFgdeaR5Qa3yYjtNdOiZlZ9bSeOuSA3SfJChAJjZaGkXhdl9Je9RunlrD9enPUrtJg==</InverseQ><D>HB8IZTlZGvSbzVGq0F325qIjCXY0/9p9wLS8AbJgEjrbs29PXyLlIhxsCqyzJ3+R7/GqNn8Eyf4xbGUcTzCkvq6Pc40tpmTrn6WK+zWia7Fza3db9/OP74VmBvMLhWCzlhfIcenb/00RaG+RH/gxdv9AOLw1ODW0F8Jap74cpI0=</D></RSAKeyValue>";
            PublicKey = WebConfigurationManager.AppSettings["PublicKey"].ToString();
            AESKey = WebConfigurationManager.AppSettings["AESKey"].ToString();

            Host = WebConfigurationManager.AppSettings["MailingHost"].ToString();
            Port = Convert.ToInt32(WebConfigurationManager.AppSettings["MailingPort"]);
            SenderEmail = WebConfigurationManager.AppSettings["SenderEmail"].ToString();
            EmailUser = WebConfigurationManager.AppSettings["EmailUser"].ToString();
            EmailPwd = WebConfigurationManager.AppSettings["EmailPwd"].ToString();
            DontSendMail = Convert.ToBoolean(WebConfigurationManager.AppSettings["DontSendMail"]);
            SendActualMails = Convert.ToBoolean(WebConfigurationManager.AppSettings["SendActualMails"]);
            SendDefaultEmailTo = WebConfigurationManager.AppSettings["SendDefaultEmailTo"].ToString();
            SavePasswords = Convert.ToBoolean(WebConfigurationManager.AppSettings["SavePasswords"]);
            EmailLinkExpiry = Convert.ToInt32(WebConfigurationManager.AppSettings["EmailLinkExpiry"]);
            ForgotPwdClickAgain = Convert.ToInt32(WebConfigurationManager.AppSettings["ForgotPwdClickAgain"]);

            ConfigUrl = WebConfigurationManager.AppSettings["ConfigUrl"];
            ResetPwdURL = WebConfigurationManager.AppSettings["ResetPwdURL"];

            ReCaptcha = Convert.ToBoolean(WebConfigurationManager.AppSettings["ReCaptcha"]);
            InsertErrorLog = Convert.ToBoolean(WebConfigurationManager.AppSettings["InsertErrorLog"]);
            MultiLoginEnable = Convert.ToBoolean(WebConfigurationManager.AppSettings["MultiLoginEnable"]);
            AllowedBrowsers = WebConfigurationManager.AppSettings["AllowedBrowsers"].ToString();

            InternalServerError = WebConfigurationManager.AppSettings["InternalServerError"];
            SessionExpired = WebConfigurationManager.AppSettings["SessionExpired"];
            Unauthorized = WebConfigurationManager.AppSettings["Unauthorized"];
            MultiLogin = WebConfigurationManager.AppSettings["MultiLogin"];

            EntryFrom = "Web";
            InternalServerErrorMsg = "Internal Server Error";
            InvalidUserPasswordMsg = "Invalid Email (or) Password";
            ValidationErrorMsg = "Validation Error";
            SuccessMsg = "Success";
            AccoundDisabledErrorMsg = "You Account has been Disabled for 5 Minutes as of repeated wrong Passwords";
            AccoundDisabledValidationMsg = "Account Disabled";
            ChangePwdSuccessMsg = "Change of Password is Succesfully";
            IncorrectOldPwdMsg = "Incorrect Old Password";
            DetailsUpdatedMsg = "Details Updated Successfully";
            RegistrationSuccessMsg = "Registartion is Successful";
            DuplicateMailMobileMsg = "Email / Mobile already exists";
            RegistrationSuccessMailErrorMsg = "Registartion was Successful but Email Sending Failed";
            DuplicateRecMsg = "Duplicate Record";
            EmailFailedMsg = "Email Sending Failed";
            ValidationMsg = "Validation Error";
            RecSaveSuccessMsg = "Record Saved Succesfully";
            RecUpdateSuccessMsg = "Record Updated Succesfully";
            RecDeleteSuccessMsg = "Record Deleted Succesfully";
            RecNoExistMsg = "Record Does Not Exist";

            DeveloperRole = "DEV";
            SAdminRole = "SA";
            AdminRole = "ADM";
            UserRole = "USR";
            BusinessRole = "BUS";
            CommunityRole = "COMM";

            DeveloperRedirectPage = "/CPanelDev/Dashboard";
            SAdminRedirectPage = "/CPanelSAdmin/Dashboard";
            AdminRedirectPage = "/CPanelAdmin/Dashboard";
            UserRedirectPage = "/CPanelUser/Dashboard";
            BusinessRedirectPage = "/CPanelBusiness/Dashboard";
            CommunityRedirectPage = "/CPanelCommunity/Dashboard";

            MultiLoginCheck = "Check";
            MultiLoginInsert = "Insert";
        }

        public static GlobalVariables Shared
        {
            get { return shared; }
        }
    }
}
﻿using Application.Models.SharedEntities;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Application.Helper
{
    public static class Reusable
    {
        public static string BindMenus()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            try
            {
                if (SessionHandler.Menus == null || SessionHandler.Menus == "")
                {
                    //API Call		
                    ArrayList _Array = new ArrayList();
                    _Array.Add(RSAPattern.Encrypt(_SessionUserDetails.RoleCode));
                    string _Menu = ApiHelper.PostData_Json("api/CPanel/BindMenus?Values=", _Array);
                    Result<string> _Result = JsonConvert.DeserializeObject<Result<string>>(_Menu);

                    SessionHandler.Menus = _Result.Data;
                }
                return SessionHandler.Menus;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static string RedirectPage(string RoleCode)
        {
            try
            {
                if (RoleCode == GlobalVariables.Shared.DeveloperRole)
                    return GlobalVariables.Shared.DeveloperRedirectPage;
                else if (RoleCode == GlobalVariables.Shared.UserRole)
                    return GlobalVariables.Shared.UserRedirectPage;
                else if (RoleCode == GlobalVariables.Shared.BusinessRole)
                    return GlobalVariables.Shared.BusinessRedirectPage;
                else if (RoleCode == GlobalVariables.Shared.CommunityRole)
                    return GlobalVariables.Shared.CommunityRedirectPage;
                else if (RoleCode == GlobalVariables.Shared.SAdminRole)
                    return GlobalVariables.Shared.SAdminRedirectPage;
                else if (RoleCode == GlobalVariables.Shared.AdminRole)
                    return GlobalVariables.Shared.AdminRedirectPage;
                else
                    return "";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static bool CheckIsFirstTimeLogin()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            if (_SessionUserDetails.IsFirstTimeLogin)
                return true;
            else
                return false;
        }
        public static bool BrowserCheck(string BrowserName)
        {
            try
            {
                List<string> _ext = AllowedBrowsers();
                if (_ext.Contains(BrowserName))
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private static List<string> AllowedBrowsers()
        {
            try
            {
                List<string> _ext = new List<string>();
                string[] _Values = GlobalVariables.Shared.AllowedBrowsers.Split(new string[] { "," }, StringSplitOptions.None);

                foreach (string val in _Values)
                    _ext.Add(val.Trim());

                return _ext;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> RolesList()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            try
            {
                List<SelectListItem> _List = new List<SelectListItem>();
                if (SessionHandler.Roles == null)
                {
                    //API Call
                    ArrayList _Array = new ArrayList();
                    string _Roles = ApiHelper.PostData_Json("api/CPanel/RolesList?Values=", _Array);
                    Result<List<SE_RefValues>> _ResultRoles = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_Roles);

                    _List.Add(new SelectListItem { Text = "Select Role", Value = "0" });
                    for (int k = 0; k < _ResultRoles.Data.Count; k++)
                    {
                        _List.Add(new SelectListItem
                        {
                            Text = _ResultRoles.Data[k].Description.ToString(),
                            Value = _ResultRoles.Data[k].Id.ToString()
                        });
                    }
                    SessionHandler.Roles = _List;
                }
                return SessionHandler.Roles;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> GenderList()
        {
            try
            {
                List<SelectListItem> GenderList = new List<SelectListItem>();
                GenderList.Add(new SelectListItem { Text = "Select Gender", Value = "0" });
                GenderList.Add(new SelectListItem { Text = "Male", Value = "1" });
                GenderList.Add(new SelectListItem { Text = "Female", Value = "2" });
                GenderList.Add(new SelectListItem { Text = "Other", Value = "3" });
                return GenderList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> CountriesList()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            try
            {
                List<SelectListItem> CountriesList = new List<SelectListItem>();
                if (SessionHandler.Countries == null)
                {
                    //API Call
                    ArrayList _Array = new ArrayList();
                    string _Countries = ApiHelper.PostData_Json("api/CPanel/GetCountries?Values=", _Array);
                    Result<List<SE_RefValues>> _ResultCountries = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_Countries);

                    CountriesList.Add(new SelectListItem { Text = "Select Country", Value = "0" });
                    for (int k = 0; k < _ResultCountries.Data.Count; k++)
                    {
                        CountriesList.Add(new SelectListItem
                        {
                            Text = _ResultCountries.Data[k].Description.ToString(),
                            Value = _ResultCountries.Data[k].Id.ToString()
                        });
                    }
                    SessionHandler.Countries = CountriesList;
                }
                return SessionHandler.Countries;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> StatesList()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            try
            {
                List<SelectListItem> StatesList = new List<SelectListItem>();
                if (SessionHandler.States == null)
                {
                    ArrayList _Array = new ArrayList();
                    string _States = ApiHelper.PostData_Json("api/CPanel/GetStates?Values=", _Array);
                    Result<List<SE_RefValues>> _ResultStates = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_States);

                    StatesList.Add(new SelectListItem { Text = "Select State", Value = "0" });
                    for (int i = 0; i < _ResultStates.Data.Count; i++)
                    {
                        StatesList.Add(new SelectListItem
                        {
                            Text = _ResultStates.Data[i].Description.ToString(),
                            Value = _ResultStates.Data[i].Id.ToString()
                        });
                    }
                    SessionHandler.States = StatesList;
                }
                return SessionHandler.States;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<string> ProfilePicExtentions()
        {
            try
            {
                List<string> _ext = new List<string>();
                _ext.Add(".JPG");
                _ext.Add(".JPEG");
                _ext.Add(".PNG");
                _ext.Add(".jpg");
                _ext.Add(".jpge");
                _ext.Add(".png");
                return _ext;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static void SaveTempPasswords(string _Email, string _Pwd, string _Salt)
        {
            var _BreakLine = Environment.NewLine;

            try
            {
                string filepath = System.Web.HttpContext.Current.Server.MapPath("~/Temp/");  //Text File Path
                if (!Directory.Exists(filepath))
                    Directory.CreateDirectory(filepath);

                filepath = filepath + "TempPasswords.txt";   //Text File Name
                if (!File.Exists(filepath))
                    File.Create(filepath).Dispose();

                using (StreamWriter sw = File.AppendText(filepath))
                {
                    string _Details = "Date & Time:" + " " + DateTime.Now.ToString() + _BreakLine;
                    _Details = _Details + "Email:" + " " + _Email + _BreakLine;
                    _Details = _Details + "Password:" + " " + _Pwd + _BreakLine;
                    _Details = _Details + "Salt Key:" + " " + _Salt;

                    sw.WriteLine("-----------------------------------------------------------------");
                    sw.WriteLine(_Details);
                    sw.WriteLine("------------------------------/End/------------------------------");
                    sw.WriteLine(_BreakLine);
                    sw.Flush();
                    sw.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static void SaveResetPwdLink(string _Email, string _Name, string _Url)
        {
            var _BreakLine = Environment.NewLine;

            try
            {
                string filepath = System.Web.HttpContext.Current.Server.MapPath("~/Temp/");  //Text File Path
                if (!Directory.Exists(filepath))
                    Directory.CreateDirectory(filepath);

                filepath = filepath + "TempResetPwdLinks.txt";   //Text File Name
                if (!File.Exists(filepath))
                    File.Create(filepath).Dispose();

                using (StreamWriter sw = File.AppendText(filepath))
                {
                    string _Details = "Date & Time:" + " " + DateTime.Now.ToString() + _BreakLine;
                    _Details = _Details + "Email:" + " " + _Email + _BreakLine;
                    _Details = _Details + "Password:" + " " + _Name + _BreakLine;
                    _Details = _Details + "URL:" + " " + _Url;

                    sw.WriteLine("-----------------------------------------------------------------");
                    sw.WriteLine(_Details);
                    sw.WriteLine("------------------------------/End/------------------------------");
                    sw.WriteLine(_BreakLine);
                    sw.Flush();
                    sw.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static void SaveRegistration(string _PKey, string _Email, string _FName, string _LName, string _Mobile)
        {
            var _BreakLine = Environment.NewLine;

            try
            {
                string filepath = System.Web.HttpContext.Current.Server.MapPath("~/Temp/");  //Text File Path
                if (!Directory.Exists(filepath))
                    Directory.CreateDirectory(filepath);

                filepath = filepath + "TempRegistrations.txt";   //Text File Name
                if (!File.Exists(filepath))
                    File.Create(filepath).Dispose();

                using (StreamWriter sw = File.AppendText(filepath))
                {
                    string _Details = "Date & Time:" + " " + DateTime.Now.ToString() + _BreakLine;
                    _Details = _Details + "Actual Email:" + " " + SymmetricAlgorithm.Decrypt(_Email) + _BreakLine;
                    _Details = _Details + "PersonalKey:" + " " + _PKey + _BreakLine;
                    _Details = _Details + "Email:" + " " + _Email + _BreakLine;
                    _Details = _Details + "FName:" + " " + _FName + _BreakLine;
                    _Details = _Details + "LName:" + " " + _LName + _BreakLine;
                    _Details = _Details + "Mobile:" + " " + _Mobile + _BreakLine;

                    sw.WriteLine("-----------------------------------------------------------------");
                    sw.WriteLine(_Details);
                    sw.WriteLine("------------------------------/End/------------------------------");
                    sw.WriteLine(_BreakLine);
                    sw.Flush();
                    sw.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static List<SelectListItem> RoomTypes()
        {
            try
            {
                List<SelectListItem> _Type = new List<SelectListItem>();
                _Type.Add(new SelectListItem { Text = "Select Room Type", Value = "0" });
                _Type.Add(new SelectListItem { Text = "Sharing Basis", Value = "Sharing Basis" });
                _Type.Add(new SelectListItem { Text = "Complete Flat / House", Value = "Complete Flat / House" });
                return _Type;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}